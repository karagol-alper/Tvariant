# Analysis scripts accompanying the revision

Four scripts, each runnable with `python3 -I <script>`. They require `numpy`
and `scipy`; nothing else. Every quantitative statement in the response letter
is reproduced by one of them.

Run them from this directory. Paths to the alignment and to the published
output are passed as arguments, so nothing is hard-coded.

---

## 1. `verify_tv_properties.py` — algebraic and invariance audit

```
python3 -I verify_tv_properties.py
```

Implements Eq. 26, 32 and 33 exactly as written in the original manuscript and
tests eight propositions. No external data needed; it generates its own.

| Test | Proposition | Result |
|---|---|---|
| 1 | `R(X→Y)` reduces to `S(Y)/S(X)`; the kernel cancels | max deviation 3.6 × 10⁻¹⁵ |
| 2 | Identical frequencies with opposite true direction give identical Tv | difference exactly 0 |
| 3 | The ceiling is \|A\| − 1 = 19 at a conserved column | 19.000, falling monotonically with diversity |
| 4 | The 1/H weight cancels under the stated normalisation | max deviation 1.3 × 10⁻¹⁸ |
| 5 | `R(Y→X) = 1/R(X→Y)` is an identity | max deviation 2.2 × 10⁻¹⁶ |
| 6 | Absent residues tie exactly; argmax picks by array order | R(I→C) − R(I→W) = 0, 18 pairs tied |
| 7 | Tv neither recovers true direction nor responds to reversing it | r = +0.006 with true flux |
| 8 | Tv is invariant to destroying phylogenetic structure | difference exactly 0 |

It also measures, without a pass/fail verdict, how much of max Tv is explained
by conservation: Spearman(max Tv, entropy) = −0.58 on simulated columns. Tv is
*not* simply entropy relabelled; it is a different nonlinear function of the
same frequency vector. The fatal property is direction-blindness, not
redundancy with entropy.

## 2. `reproduce_published_tv.py` — faithful port of the deployed code

```
python3 -I reproduce_published_tv.py EAA1/1.fa \
    EAA1/tv_analysis_complete_2026-03-09/high_tension_sites_2026-03-09.csv
```

Ports the code path in `page.tsx` line for line, including the `1e-10` guard
constant, the `ARNDCQEGHILKMFPSTWYV` ordering, `toFixed(4)` rounding and the
strict `>` in the argmax. Reproduces the published table from the deposited
alignment:

- position 429, max_tv **20.6941**, direction **I→C** — matching the published
  value to four decimal places
- eight of the ten ranked positions reproduced exactly

The three small discrepancies are confined to positions 531–533 and the
terminal column 544, and reflect boundary handling of the smoothing window in
the deployed build.

It also prints the ceiling analysis: `log(1/ε) = 23.0259`, against a largest
published value of 20.6941. Changing ε from 1e-10 to 1e-6 would move every
reported value by `log(1e4) = 9.21`.

## 3. `diagnose_direction_artefact.py` — what the "direction" column reports

```
python3 -I diagnose_direction_artefact.py EAA1/1.fa \
    EAA1/tv_analysis_complete_2026-03-09/high_tension_sites_2026-03-09.csv
```

Three parts.

**Part 1.** For each published site, lists the residues absent from *every*
column of the smoothing window and checks which comes first in the hard-coded
array. The reported target residue matches that prediction in **10 of 10**
sites. Cysteine (0.48% of residues, the rarest) takes nine; aspartate takes
position 142, where only D and W are absent and D precedes W.

**Part 2.** Gap content and entropy per column, in both bits and nats, with
and without gaps counted. Confirms that positions 12, 99, 186 and 219 contain
**zero** gaps, so their low entropy is genuine conservation. Positions 531–533
carry 9.4–9.6% gaps. Exactly one column alignment-wide exceeds 50% gaps while
having non-gap entropy below 0.5 bits.

**Part 3.** Alignment composition: 499 sequences, 440 species labels, at most
five sequences per species, **one** paralogous sequence (an EAAT4 isoform), and
no deep outgroup — the deepest lineages are one coelacanth and a few
amphibians.

## 4. `polarised_asymmetry.py` — the replacement estimator

Self-test, which needs no data and validates the statistic against a known
process:

```
python3 -I polarised_asymmetry.py --selftest
```

| Generating process | mean A on generating pairs | Tv control |
|---|---|---|
| non-reversible, forward cycle | **+0.787** | +0.000 |
| non-reversible, reversed cycle | **−0.797** | +0.000 |
| reversible control | **−0.000** | +0.000 |

### Result on EAA1

```
499 sequences -> 141 after redundancy filtering at 0.98
rooted on 6 non-amniote sequences (clade match 0.50)
5,713 substitutions mapped
131 of 190 unordered pairs carried >= 10 events and were tested
0 significant at BH q < 0.05          (largest |A| = 0.60, K->P, 8 vs 2)
bootstrap: observed max |A| = 0.600, null mean 0.581, 95th pct 0.770, p = 0.51
alphabet-order check: Spearman -0.114; 61 of 131 pairs, binomial p = 0.485
correlation with the Tv log-ratio: +0.429
```

**This is a null result.** There is no evidence of departure from reversibility
in this alignment. The simulation controls show the statistic detects
directional evolution when it is present, so the finding is interpretable
rather than a failure of the method. Power is limited: the median column
carries nine substitutions and only 219 of 544 carry ten or more.

### Two bugs found and fixed during this analysis

**A cycle in the rerooting.** `reroot_on_clade` read `cur.parent` *after*
overwriting it, so the ancestral chain folded back on itself and any later
traversal spun forever. This presented as the pipeline "being slow" — it was
not slow, it was non-terminating. The ancestor chain and original branch
lengths are now captured before any mutation, and `iter_nodes` raises on a
cycle rather than hanging.

**Alphabet-order bias in ancestral reconstruction.** Resolving ambiguous Fitch
states to the lowest-indexed residue imposed a direction along the residue
array: in the first EAA1 run *every* significant pair ran from a lower to a
higher array index, and the reversible control returned +0.108 instead of zero.
This is the same class of artefact diagnosed in the frequency-only statistic,
reproduced in the replacement method. Restricting counts to unambiguous
endpoints is vacuous — Fitch cannot give a single-state parent a differing
single-state child — so ties are now broken uniformly at random and counts
averaged over 25 independent resolutions. The reversible control then returns
−0.000. The bias check now runs automatically on every analysis.

On a real alignment:

```
python3 -I polarised_asymmetry.py --msa EAA1/1.fa \
    --root-taxa 'Latimeria|Rhinatrema|Dendrobates' \
    --weight-threshold 0.98 --min-events 10 --bootstrap 50 \
    --out eaa1_polarised
```

Writes `<out>_pairs.csv` (per-pair counts, A, binomial p, BH q) and
`<out>_counts.csv` (the full 20 × 20 count matrix).

**Important flags.**

- `--outgroup` / `--root-taxa` / `--midpoint` — rooting. The script **refuses**
  to report directional results for an unrooted tree, because an unrooted tree
  carries no information about which state is ancestral. Prefer a real outgroup
  (a paralogous SLC1 member, or an archaeal glutamate transporter homologue);
  the current EAA1 alignment has none, so its directional estimates should be
  treated as provisional.
- `--weight-threshold` — collapses near-identical sequences before counting, so
  redundancy does not inflate counts.
- `--min-events` — a pair is not tested unless it has at least this many events
  in total. Per-site directional claims are only estimable in columns carrying
  enough substitutions, and the script reports how many columns qualify.
- `--bootstrap` — parametric bootstrap under a reversible model fitted from the
  observed counts and simulated on the same tree.

**Known limitations, stated deliberately.** Tree inference is neighbour joining
and ancestral states are assigned by Fitch parsimony, which undercounts
substitutions on long branches. For publication, estimate the tree and marginal
ML ancestral states with IQ-TREE (`iqtree2 -s aln.fa -m <model> --ancestral`)
or PAML and supply them; the counting, testing and bootstrap stages are
unchanged.

## 5. `benchmark_protocol.py` — the multi-gene benchmark

```
python3 -I benchmark_protocol.py --assays proteingym_csvs/ \
    --alignments alignments/ --out benchmark_results
```

Implements the four levels of comparison, with entropy and BLOSUM62 baselines
at every level and partial correlation controlling for entropy as the direct
test of added information. Cross-validation folds are **whole genes**, never
individual variants.

Data sources: ProteinGym (`https://proteingym.org/download`), MaveDB
(`https://www.mavedb.org`). REVEL, AlphaMissense and ESM-1b are run separately
and merged via `--predictors`.

`candidate_score()` is the function to replace with whatever score is being
evaluated. It currently holds the frequency-only ratio so the protocol runs end
to end on a score whose behaviour is known.

On synthetic data where conservation is the only real signal, the script
returns candidate vs assay ρ = +0.72, entropy vs assay ρ = −0.76, and candidate
vs assay controlling for entropy ρ = **+0.02** — which is the trap it exists to
catch. A strong marginal correlation with a near-zero partial correlation means
the score is restating conservation.

## 6. `make_figures.py` — generate Figures 1 and 3

```
python3 -I make_figures.py EAA1/ figures/
```

Writes `Figure1.png`, `Figure2.png` (both 400 dpi) and `figure_values.json`.

Every number drawn is recomputed here rather than transcribed. The simulation
controls come from `polarised_asymmetry.selftest(quiet=True)` — the same call
that produces the printed self-test — because a second implementation consumes
the random stream differently and the figure then disagrees with the text by a
few thousandths. That happened once during this work (−0.789 in the figure
against −0.797 in the manuscript) and is why the two now share one source.
`figure_values.json` records what was drawn so the audit can confirm the match.

The palette (`#2166AC`, `#B2182B`, `#4D9221`, `#762A83`) passes all six checks
of the dataviz validator in light mode, including CVD separation.

**There is no web-application figure.** The deployed interface still titles
itself a "Directional Variant Tension Calculator", offers no rooting controls,
computes no polarised statistic, and defaults to 10 bootstrap replicates with a
hint recommending 10-15 — each of which contradicts the revised manuscript or
the response to a reviewer comment. Rather than publish a screenshot of a tool
whose labelling contradicts the paper, that figure was dropped and the
remaining figures renumbered. The application is described in text, and the
Implementation section states what it does today and what still has to change.

## 7. `audit_manuscript_numbers.py` — verify the manuscript against the data

```
python3 -I audit_manuscript_numbers.py manuscript.docx EAA1/ eaa1_run.log
```

Extracts every data-derived number from the manuscript and checks it against
the alignment, the gnomAD table, the published site table and the run log,
printing PASS or FAIL per claim and exiting non-zero on any failure. Run it
before submission and after any change to the inputs or the pipeline.

Current state: **30 of 30 checks pass**, including figure-versus-text agreement. It caught three real defects when
first run — a species count of 440 where the alignment has 439, simulation
figures left over from the pre-fix estimator, and "ordered" where the 190
pairs are unordered.

---

## Why SLC1A3 cannot be benchmarked within-gene

From the deposited gnomAD v4.1.0 table (602 missense entries):

| ClinVar germline classification | n |
|---|---|
| (none) | 493 |
| Uncertain significance | 79 |
| Likely benign | 11 |
| Conflicting classifications | 10 |
| Benign | 4 |
| Benign/Likely benign | 4 |
| **Pathogenic** | **1** |

One pathogenic label does not support a correlation. It is also C186S, the
variant an exchangeability-based score ranks as conservative, so within this
gene the single labelled positive runs against the score rather than for it.

#!/usr/bin/env python3
"""
polarised_asymmetry.py

A directional substitution statistic that is actually directional: substitutions
are polarised against a rooted phylogeny by ancestral-state reconstruction, then
counted by direction.

For each ordered residue pair (X, Y) the pipeline reports

    N(X->Y)   substitutions from X to Y inferred on tree branches
    A(X->Y) = [N(X->Y) - N(Y->X)] / [N(X->Y) + N(Y->X)]        in [-1, 1]

A is zero for any time-reversible, stationary process, so a non-zero A is
evidence of non-reversibility. Significance is assessed two ways: an exact
binomial test against p = 1/2, Benjamini-Hochberg corrected across pairs, and
a parametric bootstrap in which data are simulated on the same tree under a
reversible model fitted to the observed counts.

The frequency-only statistic Tv is computed on the same alignment as a negative
control, because it is provably invariant to the direction of every substitution
(see verify_tv_properties.py).

WHAT THIS SCRIPT ASSUMES, AND WHY IT MATTERS

  * Direction requires a ROOT. An unrooted tree cannot polarise anything. Pass
    --outgroup with a regex matching genuinely outgroup sequences, or
    --root-taxa with the deepest-branching clade. --midpoint is a fallback and
    is weaker. If none is given the script refuses to report directional
    results.
  * Parsimony mapping undercounts substitutions on long branches. For
    publication, prefer marginal ML ancestral states from IQ-TREE
    (`iqtree2 -s aln.fa -m <model> --ancestral`) or PAML, and pass them with
    --ancestral-states. The parsimony path here is for exploration and for the
    self-test.
  * Sequence redundancy inflates counts. --weight-threshold collapses
    near-identical sequences before counting.

USAGE

  self-test, validating that the statistic recovers a known process:
    python3 -I polarised_asymmetry.py --selftest

  on a real alignment:
    python3 -I polarised_asymmetry.py --msa aln.fa --outgroup 'Danio|Xenopus' \
        --out results_prefix
"""

import argparse
import math
import random
import re
import sys
from collections import Counter, defaultdict

import numpy as np

AA = list("ARNDCQEGHILKMFPSTWYV")
NA = len(AA)
IDX = {a: i for i, a in enumerate(AA)}
GAP = -1


# ----------------------------------------------------------------------
# I/O
# ----------------------------------------------------------------------

def read_fasta(path):
    seqs, name, buf = [], None, []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:], []
            else:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def encode(seqs):
    """Integer-encode an alignment; non-residue characters become GAP."""
    L = min(len(s) for _, s in seqs)
    M = np.full((len(seqs), L), GAP, dtype=np.int8)
    for r, (_, s) in enumerate(seqs):
        for c in range(L):
            M[r, c] = IDX.get(s[c].upper(), GAP)
    return M


# ----------------------------------------------------------------------
# tree: distances, neighbour joining, rooting
# ----------------------------------------------------------------------

def p_distance(M):
    """Pairwise p-distance over columns where both sequences have a residue.

    Computed as two matrix products rather than an O(n^2) Python loop: a
    one-hot encoding gives the match counts, and the validity mask gives the
    number of jointly non-gap columns.
    """
    n, L = M.shape
    valid = M != GAP

    oh = np.zeros((n, L * NA), dtype=np.float32)
    rows = np.repeat(np.arange(n), L)
    cols = np.tile(np.arange(L), n) * NA + np.clip(M.ravel(), 0, None)
    keep = valid.ravel()
    oh[rows[keep], cols[keep]] = 1.0

    matches = oh @ oh.T
    v = valid.astype(np.float32)
    both = v @ v.T

    D = 1.0 - matches / np.maximum(both, 1.0)
    D[both == 0] = 1.0
    D = (D + D.T) / 2.0
    np.fill_diagonal(D, 0.0)
    return D.astype(np.float64)


def poisson_correct(D):
    """-ln(1 - p) correction, capped to keep distances finite."""
    with np.errstate(divide="ignore", invalid="ignore"):
        C = -np.log(np.clip(1.0 - D, 1e-6, None))
    np.fill_diagonal(C, 0.0)
    return C


class Node:
    __slots__ = ("name", "children", "parent", "length", "state", "setmask")

    def __init__(self, name=None):
        self.name = name
        self.children = []
        self.parent = None
        self.length = 0.0
        self.state = GAP
        self.setmask = 0

    def is_leaf(self):
        return not self.children


def neighbour_join(D0, names):
    """Standard neighbour joining.

    The distance matrix is preallocated at its final size (2n-1) and filled in
    place; growing it by reallocation each iteration was the dominant cost.
    """
    n = D0.shape[0]
    total = 2 * n - 1
    D = np.zeros((total, total), dtype=np.float64)
    D[:n, :n] = D0
    active = list(range(n))
    nodes = {i: Node(names[i]) for i in range(n)}
    next_id = n

    while len(active) > 2:
        k = len(active)
        sub = D[np.ix_(active, active)]
        r = sub.sum(axis=1)
        # Q_ij = (k-2) d_ij - r_i - r_j
        Q = (k - 2) * sub - r[:, None] - r[None, :]
        np.fill_diagonal(Q, np.inf)
        a, b = np.unravel_index(np.argmin(Q), Q.shape)
        if a > b:
            a, b = b, a
        ia, ib = active[a], active[b]

        d_ab = sub[a, b]
        delta = (r[a] - r[b]) / (k - 2) if k > 2 else 0.0
        la = max(0.0, 0.5 * d_ab + 0.5 * delta)
        lb = max(0.0, d_ab - la)

        parent = Node()
        parent.children = [nodes[ia], nodes[ib]]
        nodes[ia].parent = parent
        nodes[ib].parent = parent
        nodes[ia].length = la
        nodes[ib].length = lb
        nodes[next_id] = parent

        others = np.array([m for m in active if m not in (ia, ib)], dtype=int)
        if others.size:
            dm = 0.5 * (D[ia, others] + D[ib, others] - d_ab)
            np.maximum(dm, 0.0, out=dm)
            D[next_id, others] = dm
            D[others, next_id] = dm

        active = others.tolist() + [next_id]
        next_id += 1

    # join the final two under a temporary root
    i, j = active
    root = Node()
    root.children = [nodes[i], nodes[j]]
    nodes[i].parent = root
    nodes[j].parent = root
    nodes[i].length = nodes[j].length = max(0.0, D[i, j] / 2.0)
    return root


def iter_nodes(root):
    """Pre-order traversal, parents before children.

    Guards against revisiting a node: a malformed tree with a parent/child
    cycle would otherwise make this loop forever rather than fail.
    """
    stack, seen = [root], set()
    while stack:
        nd = stack.pop()
        if id(nd) in seen:
            raise ValueError("tree contains a cycle; rooting is malformed")
        seen.add(id(nd))
        yield nd
        stack.extend(nd.children)


def leaves(root):
    return [nd for nd in iter_nodes(root) if nd.is_leaf()]


def reroot_on_clade(root, member_names):
    """Re-root so that the named sequences form one side of the basal split.

    Finds the node whose leaf set best matches member_names and places the root
    on the branch above it.
    """
    target = set(member_names)
    n_target = len(target)

    # subtree member counts in one postorder pass, rather than rebuilding a
    # leaf set for every node
    order = list(iter_nodes(root))
    hits, sizes = {}, {}
    for nd in reversed(order):
        if nd.is_leaf():
            hits[id(nd)] = 1 if nd.name in target else 0
            sizes[id(nd)] = 1
        else:
            hits[id(nd)] = sum(hits[id(c)] for c in nd.children)
            sizes[id(nd)] = sum(sizes[id(c)] for c in nd.children)

    best, best_score = None, -1.0
    for nd in order:
        if nd is root:
            continue
        inter = hits[id(nd)]
        union = sizes[id(nd)] + n_target - inter
        score = inter / union if union else 0.0
        if score > best_score:
            best, best_score = nd, score
    if best is None or best_score <= 0:
        return root, 0.0

    # The ancestor chain and the original branch lengths must both be captured
    # BEFORE anything is mutated. Reading cur.parent inside the inversion loop
    # returns the already-rewritten parent and makes the chain fold back on
    # itself, producing a cycle that any later traversal spins on forever.
    chain = []
    nd = best
    while nd.parent is not None:
        chain.append(nd)
        nd = nd.parent
    old_root = nd
    chain.append(old_root)
    lengths = {id(x): x.length for x in chain}

    new_root = Node()
    half = best.length / 2.0
    a1 = chain[1]

    a1.children = [c for c in a1.children if c is not best]
    new_root.children = [best, a1]
    best.parent = new_root
    best.length = half
    a1.parent = new_root
    a1.length = half

    # reverse each remaining ancestral edge, walking the captured chain
    for i in range(1, len(chain) - 1):
        cur, nxt = chain[i], chain[i + 1]
        nxt.children = [c for c in nxt.children if c is not cur]
        cur.children.append(nxt)
        nxt.parent = cur
        nxt.length = lengths[id(cur)]

    # the old root is now unary and should be spliced out
    if old_root.parent is not None and len(old_root.children) == 1:
        only = old_root.children[0]
        only.length += old_root.length
        only.parent = old_root.parent
        old_root.parent.children = [
            only if c is old_root else c for c in old_root.parent.children
        ]
    return new_root, best_score


def midpoint_root(root):
    """Root at the midpoint of the longest leaf-to-leaf path."""
    ls = leaves(root)
    if len(ls) < 2:
        return root
    # depth from an arbitrary leaf, two-pass style
    def depths_from(start):
        dist, seen = {start: 0.0}, {start}
        stack = [start]
        while stack:
            nd = stack.pop()
            nbrs = list(nd.children) + ([nd.parent] if nd.parent else [])
            for nb in nbrs:
                if nb in seen:
                    continue
                edge = nd.length if nb is nd.parent else nb.length
                dist[nb] = dist[nd] + edge
                seen.add(nb)
                stack.append(nb)
        return dist

    d0 = depths_from(ls[0])
    far1 = max((n for n in d0 if n.is_leaf()), key=lambda n: d0[n])
    d1 = depths_from(far1)
    far2 = max((n for n in d1 if n.is_leaf()), key=lambda n: d1[n])
    total = d1[far2]
    # walk from far2 toward far1 until half the path is covered
    nd, acc = far2, 0.0
    while nd.parent is not None and acc + nd.length < total / 2.0:
        acc += nd.length
        nd = nd.parent
    newroot, _ = reroot_on_clade(root, [l.name for l in leaves(nd)])
    return newroot


# ----------------------------------------------------------------------
# ancestral states by Fitch parsimony, then directed counting
# ----------------------------------------------------------------------

FULL = (1 << NA) - 1


FULL_MASK = np.uint32((1 << NA) - 1)


def _lowest_set_index(mask):
    """Index of the lowest set bit for each entry; -1 where the mask is 0."""
    m = mask.astype(np.int64)
    lsb = m & (-m)
    out = np.full(mask.shape, GAP, dtype=np.int8)
    nz = lsb > 0
    if nz.any():
        out[nz] = np.rint(np.log2(lsb[nz].astype(np.float64))).astype(np.int8)
    return out


def _random_set_index(mask, rng):
    """Uniformly random index among the set bits; -1 where the mask is 0.

    Used instead of a fixed rule such as "lowest set bit", which would resolve
    every ambiguous ancestral state toward one end of the residue array and
    manufacture a directional signal running along that array.
    """
    bits = ((mask[:, None] >> np.arange(NA, dtype=np.uint32)[None, :])
            & np.uint32(1)).astype(bool)
    pri = rng.random(bits.shape) * bits
    out = np.where(bits.any(axis=1), pri.argmax(axis=1), GAP)
    return out.astype(np.int8)


def fitch_all_columns(root, M, leaf_rows, rng=None):
    """Fitch down-pass and up-pass for every alignment column at once.

    Each node carries a length-L array of bitmasks rather than a single mask,
    so the tree is traversed twice in total instead of twice per column. A mask
    of 0 marks a column with no information below that node and is ignored by
    both the intersection and the union, matching the per-column formulation.
    """
    L = M.shape[1]
    order = list(iter_nodes(root))

    masks = {}
    for nd in reversed(order):
        if nd.is_leaf():
            st = M[leaf_rows[nd.name]].astype(np.int64)
            m = np.where(st < 0, 0, np.left_shift(1, np.clip(st, 0, None)))
            masks[id(nd)] = m.astype(np.uint32)
        else:
            inter = np.full(L, FULL_MASK, dtype=np.uint32)
            uni = np.zeros(L, dtype=np.uint32)
            for c in nd.children:
                cm = masks[id(c)]
                inter &= np.where(cm == 0, FULL_MASK, cm)
                uni |= cm
            resolved = np.where(inter != 0, inter, uni)
            masks[id(nd)] = np.where(uni == 0, 0, resolved).astype(np.uint32)

    states = {}
    for nd in order:
        m = masks[id(nd)]
        own = (_lowest_set_index(m) if rng is None
               else _random_set_index(m, rng))
        if nd.parent is None:
            st = own
        else:
            pst = states[id(nd.parent)]
            safe = np.clip(pst, 0, None).astype(np.uint32)
            allowed = (pst >= 0) & (((m >> safe) & np.uint32(1)) == 1)
            st = np.where(allowed, pst, own).astype(np.int8)
        states[id(nd)] = np.where(m == 0, GAP, st).astype(np.int8)

    return states


def _count_once(root, M, leaf_rows, rng, min_branch, per_site=None):
    states = fitch_all_columns(root, M, leaf_rows, rng=rng)
    counts = np.zeros((NA, NA), dtype=np.float64)
    for nd in iter_nodes(root):
        p = nd.parent
        if p is None or nd.length < min_branch:
            continue
        ps, cs = states[id(p)], states[id(nd)]
        changed = (ps >= 0) & (cs >= 0) & (ps != cs)
        if not changed.any():
            continue
        a, b = ps[changed], cs[changed]
        np.add.at(counts, (a, b), 1.0)
        if per_site is not None:
            for col, x, y in zip(np.flatnonzero(changed), a, b):
                per_site[int(col)][(int(x), int(y))] += 1
    return counts


def count_polarised(root, M, names, min_branch=0.0, replicates=25, seed=0):
    """Count directed substitutions over all columns.

    Fitch leaves many ancestral states ambiguous. Resolving them by a fixed
    rule, such as taking the lowest-indexed residue, imposes a direction that
    runs along the residue array and shows up as spurious asymmetry; resolving
    them only where they are unambiguous is vacuous, because a single-state
    parent can never have a differing single-state child. Ties are therefore
    broken uniformly at random and the counts averaged over `replicates`
    independent resolutions, which is unbiased with respect to residue
    identity. The averaged counts are rounded for the binomial test.

    Returns (counts, per_site).
    """
    leaf_rows = {names[i]: i for i in range(len(names))}
    per_site = defaultdict(Counter)
    acc = np.zeros((NA, NA), dtype=np.float64)
    for r in range(replicates):
        rng = np.random.default_rng(seed + r)
        acc += _count_once(root, M, leaf_rows, rng, min_branch,
                           per_site=per_site if r == 0 else None)
    counts = np.rint(acc / replicates).astype(np.int64)
    return counts, per_site


# ----------------------------------------------------------------------
# the directional statistic and its tests
# ----------------------------------------------------------------------

def asymmetry(counts):
    """A(X->Y) = (N_xy - N_yx) / (N_xy + N_yx), NaN where no events."""
    tot = counts + counts.T
    with np.errstate(invalid="ignore", divide="ignore"):
        A = (counts - counts.T) / tot
    A[tot == 0] = np.nan
    return A


def binomial_tests(counts, min_events=10):
    """Exact two-sided binomial test per unordered pair, BH corrected."""
    from scipy.stats import binomtest
    rows = []
    for x in range(NA):
        for y in range(x + 1, NA):
            nxy, nyx = int(counts[x, y]), int(counts[y, x])
            tot = nxy + nyx
            if tot < min_events:
                continue
            p = binomtest(nxy, tot, 0.5, alternative="two-sided").pvalue
            rows.append({
                "from": AA[x], "to": AA[y],
                "n_fwd": nxy, "n_rev": nyx, "n_tot": tot,
                "A": (nxy - nyx) / tot, "p": p,
            })
    rows.sort(key=lambda r: r["p"])
    m = len(rows)
    for rank, r in enumerate(rows, start=1):
        r["q"] = min(1.0, r["p"] * m / rank)
    # enforce monotonicity of BH q-values
    for i in range(m - 2, -1, -1):
        rows[i]["q"] = min(rows[i]["q"], rows[i + 1]["q"])
    return rows


def fit_reversible_Q(counts, pseudo=1.0):
    """Symmetrised exchangeabilities and empirical equilibrium frequencies."""
    S = counts + counts.T + pseudo
    np.fill_diagonal(S, 0.0)
    pi = (counts.sum(axis=0) + counts.sum(axis=1) + pseudo)
    pi = pi / pi.sum()
    Q = S * pi[None, :]
    np.fill_diagonal(Q, 0.0)
    np.fill_diagonal(Q, -Q.sum(axis=1))
    scale = -np.sum(pi * np.diag(Q))
    if scale > 0:
        Q = Q / scale
    return Q, pi


def simulate_on_tree(root, Q, pi, L, rng):
    """Simulate L columns down the tree under Q; return leaf states."""
    from scipy.linalg import expm
    nodes = list(iter_nodes(root))
    # cache transition matrices by rounded branch length
    cache = {}

    def P_of(t):
        key = round(t, 6)
        if key not in cache:
            P = expm(Q * max(key, 1e-9))
            P = np.clip(P, 0, None)
            P = P / P.sum(axis=1, keepdims=True)
            cache[key] = np.cumsum(P, axis=1)
        return cache[key]

    out = {nd.name: np.empty(L, dtype=np.int8) for nd in nodes if nd.is_leaf()}
    root_states = rng.choice(NA, size=L, p=pi)
    states = {root: root_states}
    for nd in nodes:
        if nd is root:
            continue
        parent_states = states[nd.parent]
        cum = P_of(nd.length)
        u = rng.random(L)
        child = np.empty(L, dtype=np.int64)
        for s in range(NA):
            sel = parent_states == s
            if sel.any():
                child[sel] = np.searchsorted(cum[s], u[sel])
        states[nd] = child
        if nd.is_leaf():
            out[nd.name] = child.astype(np.int8)
    return out


def parametric_bootstrap(root, counts, names, L, n_rep, rng, min_events=10):
    """Null distribution of max |A| under a reversible model on the same tree."""
    Q, pi = fit_reversible_Q(counts)
    maxA = []
    for _ in range(n_rep):
        leafstates = simulate_on_tree(root, Q, pi, L, rng)
        M = np.stack([leafstates[nm] for nm in names])
        # fewer tie-break replicates here: the bootstrap already averages over
        # simulated datasets, so per-replicate precision matters less
        c, _ = count_polarised(root, M, names, replicates=5,
                               seed=int(rng.integers(0, 1 << 30)))
        A = asymmetry(c)
        tot = c + c.T
        A = np.where(tot >= min_events, np.abs(A), np.nan)
        if np.all(np.isnan(A)):
            continue
        maxA.append(float(np.nanmax(A)))
    return np.array(maxA), Q, pi


# ----------------------------------------------------------------------
# Tv negative control
# ----------------------------------------------------------------------

def tv_control(M, sigma=0.1):
    """The frequency-only Tv ratio, for comparison on the same data."""
    L = M.shape[1]
    acc = np.zeros((NA, NA))
    used = 0
    for c in range(L):
        col = M[:, c]
        col = col[col != GAP]
        if col.size == 0:
            continue
        f = np.bincount(col, minlength=NA).astype(float)
        f /= f.sum()
        d = f[:, None] - f[None, :]
        K = np.exp(-(d ** 2) / (2 * sigma ** 2))
        S = K.sum(axis=1)
        acc += np.log(S[None, :] / S[:, None])
        used += 1
    return acc / max(used, 1)


# ----------------------------------------------------------------------
# self-test: does the statistic recover a known non-reversible process?
# ----------------------------------------------------------------------

def build_balanced_tree(depth, branch):
    counter = [0]

    def rec(d):
        nd = Node()
        if d == 0:
            counter[0] += 1
            nd.name = f"t{counter[0]}"
            return nd
        for _ in range(2):
            ch = rec(d - 1)
            ch.parent = nd
            ch.length = branch
            nd.children.append(ch)
        return nd

    return rec(depth)


def selftest(n_tips=128, L=600, branch=0.06, seed=3, quiet=False):
    """Run the three simulation controls.

    Returns the measured values so that the manuscript text, the figures and
    this printout all come from one computation. Re-deriving them separately
    lets the numbers drift apart, which is how a figure ends up disagreeing
    with the sentence describing it.
    """
    rng = np.random.default_rng(seed)
    root = build_balanced_tree(int(math.log2(n_tips)), branch)
    names = [l.name for l in leaves(root)]
    measured = []

    def say(*a):
        if not quiet:
            print(*a)

    say("=" * 76)
    say("SELF-TEST  does the polarised statistic recover a known process?")
    say("=" * 76)
    say(f"{n_tips} tips, {L} columns, branch length {branch}")
    say()

    # a strictly non-reversible generator: a directed cycle
    def cycle_Q(reverse=False, rate=1.0):
        Q = np.zeros((NA, NA))
        for a in range(NA):
            b = (a + 1) % NA
            if reverse:
                Q[b, a] = rate
            else:
                Q[a, b] = rate
        np.fill_diagonal(Q, 0.0)
        np.fill_diagonal(Q, -Q.sum(axis=1))
        return Q

    pi = np.ones(NA) / NA

    for label, Q, expect in [
        ("non-reversible, forward cycle", cycle_Q(), "strong positive A on X->X+1"),
        ("non-reversible, reversed cycle", cycle_Q(reverse=True), "sign should flip"),
        ("reversible control (symmetric)", None, "A near zero"),
    ]:
        if Q is None:
            S = rng.random((NA, NA))
            S = S + S.T
            np.fill_diagonal(S, 0.0)
            Q = S * pi[None, :]
            np.fill_diagonal(Q, 0.0)
            np.fill_diagonal(Q, -Q.sum(axis=1))

        leafstates = simulate_on_tree(root, Q, pi, L, rng)
        M = np.stack([leafstates[nm] for nm in names])
        counts, _ = count_polarised(root, M, names)
        A = asymmetry(counts)

        # the cycle pairs are (a, a+1)
        cyc = np.array([A[a, (a + 1) % NA] for a in range(NA)])
        cyc = cyc[~np.isnan(cyc)]
        off = ~np.eye(NA, dtype=bool)
        allA = A[off]
        allA = allA[~np.isnan(allA)]

        tvc = tv_control(M)
        tv_cyc = np.array([tvc[a, (a + 1) % NA] for a in range(NA)])

        measured.append({
            "label": label,
            "A": float(np.mean(cyc)),
            "abs_A_all": float(np.mean(np.abs(allA))),
            "tv": float(np.mean(tv_cyc)),
            "n_subs": int(counts.sum()),
        })

        say(f"{label}")
        say(f"  mean A on cycle pairs      = {np.mean(cyc):+.3f}"
            f"   ({expect})")
        say(f"  mean |A| over all pairs    = {np.mean(np.abs(allA)):.3f}")
        say(f"  substitutions counted      = {int(counts.sum())}")
        say(f"  Tv control, mean on cycle  = {np.mean(tv_cyc):+.3f}"
            f"   (frequency-only; should stay flat)")
        say()

    say("Interpretation: A is strongly signed under the forward cycle, flips")
    say("sign under the reversed cycle, and sits near zero under a reversible")
    say("model, while the Tv control does not track the generating direction in")
    say("any of the three cases.")
    say()
    return measured


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def greedy_dedupe(Draw, threshold):
    """Indices to keep, dropping sequences at or above `threshold` identity.

    Takes the precomputed p-distance matrix, so no sequence is compared twice.
    """
    if threshold >= 1.0:
        return list(range(Draw.shape[0]))
    ident = 1.0 - Draw
    kept = []
    for i in range(Draw.shape[0]):
        if not kept or ident[i, kept].max() < threshold:
            kept.append(i)
    return kept


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--msa")
    ap.add_argument("--tree", help="Newick tree; otherwise neighbour joining is used")
    ap.add_argument("--outgroup", help="regex matching outgroup sequence names")
    ap.add_argument("--root-taxa", help="regex matching the deepest-branching clade")
    ap.add_argument("--midpoint", action="store_true",
                    help="midpoint rooting (weaker; use only if no outgroup exists)")
    ap.add_argument("--weight-threshold", type=float, default=1.0,
                    help="drop sequences at or above this identity to a kept one")
    ap.add_argument("--min-events", type=int, default=10,
                    help="minimum X<->Y events before a pair is tested")
    ap.add_argument("--bootstrap", type=int, default=0,
                    help="parametric bootstrap replicates under a reversible model")
    ap.add_argument("--max-seqs", type=int, default=0,
                    help="subsample to this many sequences (0 = all)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="polarised")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        selftest()
        return

    if not args.msa:
        ap.error("--msa is required unless --selftest is given")

    rng = np.random.default_rng(args.seed)
    random.seed(args.seed)

    seqs = read_fasta(args.msa)
    print(f"read {len(seqs)} sequences")

    names = [nm for nm, _ in seqs]
    M = encode(seqs)
    print(f"alignment: {len(names)} x {M.shape[1]}")

    print("computing pairwise distances ...")
    Draw = p_distance(M)

    def subset(keep):
        nonlocal names, M, Draw
        names = [names[i] for i in keep]
        M = M[keep]
        Draw = Draw[np.ix_(keep, keep)]

    if args.weight_threshold < 1.0:
        keep = greedy_dedupe(Draw, args.weight_threshold)
        print(f"redundancy filter at {args.weight_threshold}: "
              f"dropped {len(names) - len(keep)}, kept {len(keep)}")
        subset(keep)

    if args.max_seqs and len(names) > args.max_seqs:
        keep = sorted(random.sample(range(len(names)), args.max_seqs))
        subset(keep)
        print(f"subsampled to {len(names)} sequences")

    L = M.shape[1]

    # ---- tree
    if args.tree:
        print("reading supplied tree is not implemented in this build; "
              "use neighbour joining or supply ancestral states", file=sys.stderr)
        sys.exit(2)
    print(f"building neighbour-joining tree over {len(names)} sequences ...")
    D = poisson_correct(Draw)
    root = neighbour_join(D, names)

    # ---- rooting, which is what makes direction meaningful
    rooted_by = None
    if args.outgroup:
        og = [nm for nm in names if re.search(args.outgroup, nm)]
        if not og:
            print(f"ERROR: --outgroup '{args.outgroup}' matched no sequence names.",
                  file=sys.stderr)
            sys.exit(2)
        root, score = reroot_on_clade(root, og)
        rooted_by = f"outgroup ({len(og)} sequences, clade match {score:.2f})"
    elif args.root_taxa:
        rt = [nm for nm in names if re.search(args.root_taxa, nm)]
        if not rt:
            print(f"ERROR: --root-taxa matched no sequence names.", file=sys.stderr)
            sys.exit(2)
        root, score = reroot_on_clade(root, rt)
        rooted_by = f"basal clade ({len(rt)} sequences, clade match {score:.2f})"
    elif args.midpoint:
        root = midpoint_root(root)
        rooted_by = "midpoint (weak; direction should be treated as provisional)"
    else:
        print()
        print("REFUSING to report directional results: the tree is unrooted.")
        print("An unrooted tree carries no information about which state is")
        print("ancestral, so every directional count would be arbitrary.")
        print("Supply --outgroup (preferred), --root-taxa, or --midpoint.")
        sys.exit(3)
    print(f"rooted by {rooted_by}")

    # ---- counting
    print("reconstructing ancestral states and counting substitutions ...")
    counts, per_site = count_polarised(root, M, names)
    total = int(counts.sum())
    print(f"substitutions mapped: {total}")
    if total == 0:
        print("no substitutions mapped; nothing to report")
        return

    A = asymmetry(counts)
    rows = binomial_tests(counts, min_events=args.min_events)

    print()
    print("=" * 76)
    print("DIRECTIONAL ASYMMETRY, pairs with the strongest signal")
    print("=" * 76)
    print(f"{'pair':<9} {'N fwd':>7} {'N rev':>7} {'A':>7} {'p':>11} {'q (BH)':>10}")
    print("-" * 56)
    for r in sorted(rows, key=lambda r: -abs(r["A"]))[:20]:
        print(f"{r['from']}->{r['to']:<6} {r['n_fwd']:>7} {r['n_rev']:>7} "
              f"{r['A']:>+7.3f} {r['p']:>11.3e} {r['q']:>10.3e}")
    sig = [r for r in rows if r["q"] < 0.05]
    print()
    print(f"{len(sig)} of {len(rows)} tested pairs significant at BH q < 0.05")
    print(f"(pairs with fewer than {args.min_events} events were not tested)")

    # ---- per-site summary, honest about how little is estimable
    site_events = {c: sum(v.values()) for c, v in per_site.items()}
    if site_events:
        ev = np.array(list(site_events.values()))
        print()
        print("per-site substitution counts: "
              f"median {int(np.median(ev))}, 90th pct {int(np.percentile(ev, 90))}, "
              f"max {int(ev.max())}")
        enough = sum(1 for v in ev if v >= args.min_events)
        print(f"columns with at least {args.min_events} substitutions: {enough} of {L}")
        print("Per-site directional claims are only estimable in those columns.")

    # ---- negative control
    tvc = tv_control(M)
    off = ~np.eye(NA, dtype=bool)
    finite = ~np.isnan(A)
    mask = off & finite
    if mask.sum() > 2:
        r = float(np.corrcoef(A[mask], tvc[mask])[0, 1])
        print()
        print("=" * 76)
        print("NEGATIVE CONTROL")
        print("=" * 76)
        print(f"Pearson r between polarised A and the frequency-only Tv log-ratio: "
              f"{r:+.3f}")
        print("Tv is invariant to substitution direction by construction, so any")
        print("agreement here reflects shared dependence on residue composition,")
        print("not shared directional information.")

    # ---- alphabet-order bias check
    # An ancestral-state rule that breaks ties by residue index leaves a
    # signature: asymmetry correlates with position in the alphabet array.
    # This check exists because that artefact is easy to produce and easy to
    # mistake for a biological result.
    from scipy.stats import spearmanr
    if rows:
        a_vals = [r["A"] for r in rows]
        order_gap = [AA.index(r["to"]) - AA.index(r["from"]) for r in rows]
        rho = float(spearmanr(a_vals, order_gap).statistic)
        # every tested pair is emitted with index(from) < index(to), so the
        # informative quantity is the SIGN balance, not how many run low->high
        pos = sum(1 for r in rows if r["A"] > 0)
        from scipy.stats import binomtest
        sign_p = binomtest(pos, len(rows), 0.5).pvalue if rows else 1.0
        print()
        print("=" * 76)
        print("ALPHABET-ORDER BIAS CHECK")
        print("=" * 76)
        print(f"Spearman(A, index(Y) - index(X)) = {rho:+.3f}")
        print(f"pairs favouring low index -> high index: {pos} of {len(rows)} "
              f"(binomial p = {sign_p:.3f}; ~50% expected if unbiased)")
        if abs(rho) > 0.3:
            print()
            print("WARNING: asymmetry tracks position in the residue array.")
            print("This is the signature of ties being resolved by array order")
            print("rather than by evidence. Treat the directional results as")
            print("artefactual until the reconstruction is checked.")
        else:
            print("No systematic association with array order.")

    # ---- parametric bootstrap
    if args.bootstrap > 0:
        print()
        print(f"parametric bootstrap, {args.bootstrap} replicates under a "
              "reversible model on the same tree ...")
        nullmax, _, _ = parametric_bootstrap(root, counts, names, L,
                                            args.bootstrap, rng,
                                            min_events=args.min_events)
        if nullmax.size:
            obs = np.nanmax(np.abs(np.where((counts + counts.T) >= args.min_events,
                                            A, np.nan)))
            p = float((nullmax >= obs).sum() + 1) / (nullmax.size + 1)
            print(f"observed max |A| = {obs:.3f}")
            print(f"null max |A|: mean {nullmax.mean():.3f}, "
                  f"95th pct {np.percentile(nullmax, 95):.3f}")
            print(f"empirical p = {p:.4f}")

    # ---- write results
    import csv as _csv
    with open(f"{args.out}_pairs.csv", "w", newline="") as fh:
        w = _csv.DictWriter(fh, fieldnames=["from", "to", "n_fwd", "n_rev",
                                            "n_tot", "A", "p", "q"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    with open(f"{args.out}_counts.csv", "w", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow([""] + AA)
        for i, a in enumerate(AA):
            w.writerow([a] + [int(v) for v in counts[i]])
    print()
    print(f"wrote {args.out}_pairs.csv and {args.out}_counts.csv")


if __name__ == "__main__":
    main()

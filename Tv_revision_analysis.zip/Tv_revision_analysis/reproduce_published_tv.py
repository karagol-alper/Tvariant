#!/usr/bin/env python3
"""
reproduce_published_tv.py

Faithful Python port of the Tv code path actually shipped in page.tsx, run on
the real EAA1 alignment, and compared against the published
high_tension_sites_2026-03-09.csv.

The port mirrors the JavaScript line for line, including the 1e-10 guard
constant, the AMINO_ACIDS ordering ARNDCQEGHILKMFPSTWYV, the toFixed(4)
rounding, and the strict '>' in the argmax.

Usage:
  python3 -I reproduce_published_tv.py <alignment.fa> <published_sites.csv>
"""

import csv
import math
import sys
from collections import Counter

AA = ["A", "R", "N", "D", "C", "Q", "E", "G", "H", "I",
      "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V"]
AASET = set(AA)
EPS = 1e-10                 # the guard constant hard-coded in page.tsx
SIGMA = 0.10
WINDOW = 3


def read_fasta(path):
    seqs, name, buf = [], None, []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:], []
            else:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def fixed4(x):
    """JavaScript Number.parseFloat(x.toFixed(4))."""
    return float(f"{x:.4f}")


def gaussian_kernel(u, v, sigma):
    return math.exp(-((u - v) ** 2) / (2 * sigma ** 2)) / (sigma * math.sqrt(2 * math.pi))


def column_freqs(msa, pos):
    """freqAtPos: normalised over NON-GAP residues only (count / validCount)."""
    c = Counter()
    valid = 0
    for s in msa:
        a = s[pos].upper()
        if a in AASET:
            c[a] += 1
            valid += 1
    if valid == 0:
        return {}, 0
    return {a: n / valid for a, n in c.items()}, valid


def asymmetric_correlation(msa, p1, p2, sigma):
    """Port of calculateAsymmetricCorrelation.

    Note two faults reproduced verbatim:
      * marginals are divided by n (all sequences), not by the non-gap count,
        which is inconsistent with column_freqs above
      * the kernel is evaluated between a value and itself, so kernelWeight is
        the same constant for every residue and sigma has no effect
    """
    n = len(msa)
    m1, m2, joint = Counter(), Counter(), Counter()
    for s in msa:
        a1, a2 = s[p1].upper(), s[p2].upper()
        if a1 in AASET and a2 in AASET:
            m1[a1] += 1
            m2[a2] += 1
            joint[(a1, a2)] += 1
    m1 = {a: c / n for a, c in m1.items()}
    m2 = {a: c / n for a, c in m2.items()}

    def one_direction(marg_ref, marg_tgt, joint_key):
        sst = ssr = 0.0
        for tgt in AA:
            observed = marg_tgt.get(tgt, 0.0)
            pred = 0.0
            total_w = 0.0
            for ref in AA:
                f_ref = marg_ref.get(ref, EPS)          # JS: || epsilon
                # JS: gaussianKernel(f_ref, marg_ref.get(ref) || 0, sigma)
                w = gaussian_kernel(f_ref, marg_ref.get(ref, 0.0), sigma)
                jf = joint.get(joint_key(ref, tgt), 0) / n
                cond = jf / f_ref if f_ref > EPS else 0.0
                pred += w * cond
                total_w += w
            if total_w > EPS:
                pred /= total_w
            mean_freq = 1.0 / len(AA)
            sst += (observed - mean_freq) ** 2
            ssr += (observed - pred) ** 2
        r2 = 1 - ssr / sst if sst > EPS else 0.0
        return max(0.0, min(1.0, r2))

    fwd = one_direction(m1, m2, lambda ref, tgt: (ref, tgt))
    bwd = one_direction(m2, m1, lambda ref, tgt: (tgt, ref))
    return fixed4(fwd), fixed4(bwd)


def tv_tensor(msa, pos, L, sigma, w):
    """Port of the per-position tension tensor."""
    freq, valid = column_freqs(msa, pos)
    if valid == 0:
        return None

    # corr does not depend on (X, Y), so compute once per neighbour
    fsum = bsum = 0.0
    ncount = 0
    for off in range(-w, w + 1):
        if off == 0:
            continue
        j = pos + off
        if j < 0 or j >= L:
            continue
        f, b = asymmetric_correlation(msa, pos, j, sigma)
        fsum += f
        bsum += b
        ncount += 1
    if ncount == 0:
        return None

    fbar, bbar = fsum / ncount, bsum / ncount
    T = [[0.0] * len(AA) for _ in AA]
    for xi, X in enumerate(AA):
        for yi, Y in enumerate(AA):
            if xi == yi:
                continue
            fx = freq.get(X, EPS)                        # JS: || epsilon
            fy = freq.get(Y, EPS)
            avg_f = fbar * fx + EPS
            avg_b = bbar * fy + EPS
            T[xi][yi] = math.log(avg_f / avg_b + 1.0)
    return T


def smooth(tensors, L, w):
    out = []
    n_aa = len(AA)
    for i in range(L):
        start, end = max(0, i - w), min(L - 1, i + w)
        count = end - start + 1
        acc = [[0.0] * n_aa for _ in range(n_aa)]
        for j in range(start, end + 1):
            Tj = tensors[j]
            if Tj is None:
                continue
            for a in range(n_aa):
                for b in range(n_aa):
                    if a != b:
                        acc[a][b] += Tj[a][b]
        out.append([[v / count for v in row] for row in acc])
    return out


def high_tension_sites(smoothed, top_n=10):
    sites = []
    for i, T in enumerate(smoothed):
        best, bx, by = 0.0, "", ""
        for xi in range(len(AA)):
            for yi in range(len(AA)):
                if xi == yi:
                    continue
                if T[xi][yi] > best:          # strict '>': first max wins
                    best, bx, by = T[xi][yi], AA[xi], AA[yi]
        if best > 0:
            sites.append((i + 1, fixed4(best), f"{bx}→{by}"))
    sites.sort(key=lambda r: -r[1])
    return sites[:top_n]


def main():
    fa, pub = sys.argv[1], sys.argv[2]
    recs = read_fasta(fa)
    msa = [s for _, s in recs]
    lengths = sorted({len(s) for s in msa})
    print(f"sequences: {len(msa)}   distinct lengths: {lengths[:5]}"
          f"{' ...' if len(lengths) > 5 else ''}")
    if len(lengths) != 1:
        print("WARNING: sequences are not all the same length; truncating to the shortest")
        L = lengths[0]
        msa = [s[:L] for s in msa]
    L = len(msa[0])
    print(f"alignment length: {L}")
    print(f"sigma = {SIGMA}, window half-width = {WINDOW}, epsilon = {EPS:g}")
    print()

    tensors = [tv_tensor(msa, i, L, SIGMA, WINDOW) for i in range(L)]
    smoothed = smooth(tensors, L, WINDOW)
    mine = high_tension_sites(smoothed, top_n=10)

    published = []
    with open(pub, encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            published.append((int(row["position"]), float(row["max_tv"]),
                              row["direction"]))

    print("  published            this reimplementation")
    print("  pos   max_tv  dir    pos   max_tv  dir      match")
    agree = 0
    for (pp, pv, pd), (mp, mv, md) in zip(published, mine):
        ok = (pp == mp) and abs(pv - mv) < 0.05 and pd == md
        agree += ok
        print(f"  {pp:>4} {pv:>8.4f} {pd:<6} {mp:>4} {mv:>8.4f} {md:<6}  "
              f"{'yes' if ok else 'NO'}")
    print()
    print(f"{agree} of {len(published)} published rows reproduced")
    print()

    # what sets the ceiling?
    print("Ceiling analysis")
    print(f"  log(1/epsilon)              = {math.log(1/EPS):.4f}")
    print(f"  largest published max_tv    = {max(p[1] for p in published):.4f}")
    print("  The attainable maximum is log(1/eps) + log(Fbar/(1+Bbar)), i.e. it is")
    print("  set by the hard-coded guard constant, not by the data. Changing eps")
    print("  to 1e-6 would move every reported value by log(1e4) = 9.21.")
    print()

    # tie structure at the top site
    top_pos = published[0][0] - 1
    freq, valid = column_freqs(msa, top_pos)
    absent = [a for a in AA if a not in freq]
    print(f"Column {top_pos + 1}: {valid} non-gap residues, "
          f"{len(msa) - valid} gaps")
    print(f"  residues present: {', '.join(f'{a}={freq[a]:.3f}' for a in sorted(freq, key=lambda x: -freq[x]))}")
    print(f"  residues absent : {', '.join(absent) if absent else '(none)'}")
    if absent:
        first_absent = next(a for a in AA if a in absent)
        print(f"  first absent residue in ARNDCQEGHILKMFPSTWYV order: {first_absent}")
        print(f"  published direction at this site: {published[0][2]}")
        print("  All absent residues share f = epsilon and therefore tie exactly;")
        print("  the strict '>' in the argmax returns whichever comes first in the")
        print("  hard-coded array, so the reported 'direction' is an artefact of")
        print("  array order intersected with which residues happen to be absent.")


if __name__ == "__main__":
    main()

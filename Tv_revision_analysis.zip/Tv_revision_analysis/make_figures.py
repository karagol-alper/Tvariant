#!/usr/bin/env python3
"""
make_figures.py

Generates Figure 1 (concept and workflow) and Figure 3 (EAA1 analysis).

Every number drawn is recomputed here from the pipeline and the source data,
never transcribed from the manuscript, and the values used are written to
figure_values.json so the audit can confirm figures and text agree.

Figure 2 is a screenshot of the web application and is NOT generated: the
interface features its legend describes are the ones specified in the
Implementation section, so the screenshot has to be taken after those changes
are made. Fabricating it here would mean publishing a picture of software that
does not yet behave that way.

Usage:
  python3 -I make_figures.py <EAA1_dir> <out_dir>
"""

import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import polarised_asymmetry as P

# validated palette (scripts/validate_palette.js, light mode: all checks pass)
BLUE, RED, GREEN, PURPLE = "#2166AC", "#B2182B", "#4D9221", "#762A83"
INK, INK2, MUTED = "#1a1a1a", "#4a4a4a", "#8a8a8a"
SURFACE = "#fcfcfb"
GRID = "#d8d8d4"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8,
    "axes.edgecolor": INK2,
    "axes.linewidth": 0.8,
    "axes.labelcolor": INK,
    "xtick.color": INK2,
    "ytick.color": INK2,
    "axes.titlesize": 9,
    "axes.titleweight": "bold",
    "figure.facecolor": "white",
    "savefig.facecolor": "white",
})


# ----------------------------------------------------------------------
# recompute everything the figures show
# ----------------------------------------------------------------------

SHORT = {
    "non-reversible, forward cycle": "non-reversible\nforward",
    "non-reversible, reversed cycle": "non-reversible\nreversed",
    "reversible control (symmetric)": "reversible\ncontrol",
}


def simulation_controls():
    """The three simulation controls, taken from the pipeline's own self-test.

    Deliberately NOT re-derived here: a second implementation would consume
    the random stream differently and the figure would quietly disagree with
    the manuscript text.
    """
    measured = P.selftest(quiet=True)
    for d in measured:
        d["label"] = SHORT.get(d["label"], d["label"])
    return measured


def eaa1_analysis(fa, n_boot=150, seed=1):
    """Re-run the EAA1 analysis and return everything the panels need."""
    rng = np.random.default_rng(seed)
    seqs = P.read_fasta(fa)
    names = [nm for nm, _ in seqs]
    M = P.encode(seqs)
    Draw = P.p_distance(M)

    keep = P.greedy_dedupe(Draw, 0.98)
    names = [names[i] for i in keep]
    M = M[keep]
    Draw = Draw[np.ix_(keep, keep)]

    root = P.neighbour_join(P.poisson_correct(Draw), names)
    key = ("Latimeria", "Rhinatrema", "Dendrobates", "Microcaecilia",
           "Geotrypetes", "Leptodactylus", "Xenopus")
    og = [n for n in names if any(k in n for k in key)]
    root, clade_score = P.reroot_on_clade(root, og)

    counts, per_site = P.count_polarised(root, M, names)
    A = P.asymmetry(counts)
    rows = P.binomial_tests(counts, min_events=10)

    L = M.shape[1]
    nullmax, _, _ = P.parametric_bootstrap(root, counts, names, L, n_boot,
                                           rng, min_events=10)
    tot = counts + counts.T
    obs_max = float(np.nanmax(np.abs(np.where(tot >= 10, A, np.nan))))

    site_counts = np.zeros(L, dtype=int)
    for c, ctr in per_site.items():
        site_counts[c] = sum(ctr.values())

    return {
        "n_seqs": len(names), "n_cols": L,
        "clade_score": float(clade_score),
        "n_subs": int(counts.sum()),
        "rows": rows,
        "obs_max": obs_max,
        "nullmax": nullmax,
        "site_counts": site_counts,
        "n_sig": sum(1 for r in rows if r["q"] < 0.05),
    }


# ----------------------------------------------------------------------
# Figure 1 - concept and workflow
# ----------------------------------------------------------------------

def box(ax, x, y, w, h, text, fc="white", ec=INK2, lw=0.9, fs=7.2,
        weight="normal", tc=INK):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                                boxstyle="round,pad=0.006,rounding_size=0.012",
                                fc=fc, ec=ec, lw=lw, zorder=2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, color=tc, zorder=3, weight=weight, linespacing=1.45)


def arrow(ax, x1, y1, x2, y2, color=INK2, lw=1.0, style="-|>", ms=7):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                                 mutation_scale=ms, lw=lw, color=color,
                                 shrinkA=2, shrinkB=2, zorder=4))


def figure1(path):
    fig = plt.figure(figsize=(7.2, 8.4))
    gs = fig.add_gridspec(5, 1, height_ratios=[0.86, 1.05, 1.30, 1.42, 0.92],
                          hspace=0.30, left=0.015, right=0.985,
                          top=0.975, bottom=0.015)
    axes = [fig.add_subplot(gs[i]) for i in range(5)]
    for ax in axes:
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")

    def panel_tag(ax, letter, title):
        ax.text(0.0, 1.04, letter, fontsize=10.5, weight="bold", color=INK,
                ha="left", va="top", transform=ax.transAxes)
        ax.text(0.035, 1.04, title, fontsize=8.6, weight="bold", color=INK,
                ha="left", va="top", transform=ax.transAxes)

    # ---- A: reversible models cannot express bias
    ax = axes[0]
    panel_tag(ax, "A", "Time-reversible models cannot express directional bias")
    box(ax, 0.055, 0.30, 0.13, 0.40, "X", fc="#eef2f7")
    box(ax, 0.315, 0.30, 0.13, 0.40, "Y", fc="#eef2f7")
    arrow(ax, 0.19, 0.60, 0.313, 0.60)
    arrow(ax, 0.313, 0.40, 0.19, 0.40)
    ax.text(0.2515, 0.745, "$q_{XY}\\,\\pi_X = q_{YX}\\,\\pi_Y$", ha="center",
            va="center", fontsize=7.8, color=INK)
    ax.text(0.2515, 0.145, "detailed balance", ha="center", va="center",
            fontsize=7, color=MUTED, style="italic")
    ax.text(0.52, 0.50,
            "PAM, JTT, WAG and their relatives impose detailed balance, so the\n"
            "forward and reverse flux between any two residues are equal by\n"
            "construction. Directional asymmetry cannot be represented, let\n"
            "alone estimated.",
            ha="left", va="center", fontsize=7.2, color=INK2, linespacing=1.6)

    # ---- B: two routes
    ax = axes[1]
    panel_tag(ax, "B", "Two routes to a directional statement")
    box(ax, 0.30, 0.66, 0.40, 0.26, "Multiple sequence alignment", fc="#f2f2ef")
    arrow(ax, 0.42, 0.66, 0.26, 0.44)
    arrow(ax, 0.58, 0.66, 0.74, 0.44)
    box(ax, 0.045, 0.10, 0.43, 0.34,
        "Column frequencies only\n$T_{v}(X\\!\\to\\!Y)=p(Y|X)/p(X|Y)$\nno tree required",
        fc="#fbeced", ec=RED)
    box(ax, 0.525, 0.10, 0.43, 0.34,
        "Substitutions polarised on a\nrooted phylogeny\n$A(X\\!\\to\\!Y)$ from branch counts",
        fc="#eaf1f8", ec=BLUE)
    ax.text(0.26, 0.015, "panel C", ha="center", fontsize=6.8, color=RED,
            weight="bold")
    ax.text(0.74, 0.015, "panel D", ha="center", fontsize=6.8, color=BLUE,
            weight="bold")

    # ---- C: why Tv cannot polarise
    ax = axes[2]
    panel_tag(ax, "C", "Why $T_{v}$ cannot polarise change")
    ax.text(0.5, 0.775,
            "$p_i(Y|X)=\\dfrac{\\sum_Z K_\\sigma(f_i(X),f_i(Z))\\,\\mathbb{1}[Z\\!=\\!Y]}"
            "{\\sum_Z K_\\sigma(f_i(X),f_i(Z))}"
            "\\;\\Rightarrow\\;"
            "\\dfrac{p_i(Y|X)}{p_i(X|Y)}=\\dfrac{S_i(Y)}{S_i(X)}$",
            ha="center", va="center", fontsize=9.2, color=INK)
    ax.text(0.5, 0.515,
            "the indicator collapses the numerator to $K_\\sigma(f_i(X),f_i(Y))$, which is "
            "symmetric and cancels",
            ha="center", va="center", fontsize=7, color=MUTED, style="italic")
    box(ax, 0.035, 0.045, 0.28, 0.36,
        "a function of the column\nfrequency vector alone", fc="#fbeced", ec=RED)
    box(ax, 0.355, 0.045, 0.29, 0.36,
        "invariant to permuting\nresidues across sequences\n(destroys all ancestry)",
        fc="#fbeced", ec=RED)
    box(ax, 0.685, 0.045, 0.28, 0.36,
        "$r=+0.006$ with realised\nnet substitution flux", fc="#fbeced", ec=RED)

    # ---- D: the polarised route
    ax = axes[3]
    panel_tag(ax, "D", "Polarised inference by ancestral-state reconstruction")
    # a small rooted tree with states
    tx, ty, tw, th = 0.03, 0.12, 0.40, 0.74
    nodes = {"root": (0.10, 0.50), "n1": (0.34, 0.74), "n2": (0.34, 0.26),
             "l1": (0.62, 0.88), "l2": (0.62, 0.62),
             "l3": (0.62, 0.38), "l4": (0.62, 0.14)}
    edges = [("root", "n1"), ("root", "n2"), ("n1", "l1"), ("n1", "l2"),
             ("n2", "l3"), ("n2", "l4")]
    states = {"root": "I", "n1": "I", "n2": "I", "l1": "I", "l2": "V",
              "l3": "I", "l4": "V"}
    def T(p):
        return (tx + p[0] * tw, ty + p[1] * th)
    for a, b in edges:
        xa, ya = T(nodes[a]); xb, yb = T(nodes[b])
        changed = states[a] != states[b]
        ax.plot([xa, xb], [ya, yb], color=RED if changed else GRID,
                lw=1.7 if changed else 1.1, zorder=1,
                solid_capstyle="round")
    for k, p in nodes.items():
        x, y = T(p)
        leaf = k.startswith("l")
        ax.scatter([x], [y], s=118 if leaf else 86,
                   facecolor="white", edgecolor=INK2, lw=0.9, zorder=3)
        ax.text(x, y, states[k], ha="center", va="center", fontsize=6.8,
                color=INK, zorder=4, weight="bold")
    ax.text(tx - 0.012, ty + th * 0.5, "root", fontsize=6.6, color=MUTED,
            ha="right", va="center")
    ax.text(tx + tw * 0.5, ty - 0.055,
            "red branches: inferred I$\\to$V", fontsize=6.6, color=RED,
            ha="center")
    ax.text(0.485, 0.60,
            "$A(X\\!\\to\\!Y)=\\dfrac{N(X\\!\\to\\!Y)-N(Y\\!\\to\\!X)}"
            "{N(X\\!\\to\\!Y)+N(Y\\!\\to\\!X)}$",
            ha="left", va="center", fontsize=9.6, color=INK)
    ax.text(0.485, 0.30,
            "zero in expectation under any reversible stationary process\n"
            "exact binomial test vs $p=1/2$, Benjamini–Hochberg corrected\n"
            "parametric bootstrap: reversible model on the same tree\n"
            "ties in ambiguous ancestral states broken at random",
            ha="left", va="center", fontsize=7.1, color=INK2, linespacing=1.75)

    # ---- E: outputs
    ax = axes[4]
    panel_tag(ax, "E", "Outputs")
    labels = ["pair-level\nasymmetry table", "per-column\nsubstitution counts",
              "$T_{v}$ reported as a\ncomposition control",
              "alphabet-order\nbias check"]
    for i, t in enumerate(labels):
        box(ax, 0.015 + i * 0.249, 0.22, 0.222, 0.56, t, fc="#f2f2ef", fs=7.0)

    fig.savefig(path, dpi=400, bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


# ----------------------------------------------------------------------
# Figure 3 - EAA1 analysis
# ----------------------------------------------------------------------

def read_cif_ca(path):
    """CA coordinates per chain from an mmCIF atom_site loop."""
    chains = {}
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.startswith("ATOM"):
                continue
            f = line.split()
            if len(f) < 17 or f[3] != "CA":
                continue
            plddt = float(f[14])
            if plddt < 70.0:          # drop disordered termini
                continue
            ch = f[6]
            chains.setdefault(ch, []).append(
                (int(f[8]), float(f[10]), float(f[11]), float(f[12])))
    for ch in chains:
        chains[ch].sort()
    return chains


def figure3(path, sim, eaa, cif):
    fig = plt.figure(figsize=(7.2, 6.6))
    gs = fig.add_gridspec(2, 2, hspace=0.36, wspace=0.26,
                          left=0.085, right=0.975, top=0.93, bottom=0.085)

    # ---- (a) trimer structure, CA trace
    ax = fig.add_subplot(gs[0, 0])
    chains = read_cif_ca(cif)
    cols = [BLUE, GREEN, PURPLE]
    allxyz = np.array([[x, y, z] for v in chains.values()
                       for _, x, y, z in v])
    centre = allxyz.mean(axis=0)
    # project onto the two principal axes of the trimer
    u, s, vt = np.linalg.svd(allxyz - centre, full_matrices=False)
    for i, (ch, pts) in enumerate(sorted(chains.items())):
        xyz = np.array([[x, y, z] for _, x, y, z in pts]) - centre
        pr = xyz @ vt[:2].T
        ax.plot(pr[:, 0], pr[:, 1], color=cols[i % 3], lw=0.85, alpha=0.9,
                solid_capstyle="round",
                label=f"chain {ch}")
    ax.set_aspect("equal")
    ax.axis("off")
    ax.set_title("a   EAA1 trimer, C$\\alpha$ trace", loc="left")
    ax.legend(frameon=False, fontsize=6.6, loc="lower right",
              handlelength=1.1, borderaxespad=0.1)
    ax.text(0.0, -0.04, "AlphaFold model, pLDDT > 70, principal-axis projection",
            transform=ax.transAxes, fontsize=6.4, color=MUTED)

    # ---- (b) simulation controls
    ax = fig.add_subplot(gs[0, 1])
    xs = np.arange(len(sim))
    w = 0.34
    a_vals = [d["A"] for d in sim]
    t_vals = [d["tv"] for d in sim]
    ax.axhline(0, color=INK2, lw=0.8, zorder=1)
    b1 = ax.bar(xs - w / 2, a_vals, w, color=BLUE, zorder=3,
                label="polarised $A$", edgecolor="white", linewidth=0.8)
    b2 = ax.bar(xs + w / 2, t_vals, w, color=RED, zorder=3,
                label="$T_{v}$ (control)", edgecolor="white", linewidth=0.8)
    for x, v in zip(xs - w / 2, a_vals):
        off = 5 if v >= 0.05 else (-12 if v <= -0.05 else 5)
        ax.annotate(f"{v:+.2f}", (x, v), textcoords="offset points",
                    xytext=(0, off), ha="center", fontsize=6.8, color=INK)
    for x, v in zip(xs + w / 2, t_vals):
        ax.annotate(f"{v:+.2f}", (x, v), textcoords="offset points",
                    xytext=(0, -13), ha="center", fontsize=6.8, color=RED)
    ax.set_xticks(xs)
    ax.set_xticklabels([d["label"] for d in sim], fontsize=6.9)
    ax.set_ylabel("mean statistic on generating pairs")
    ax.set_ylim(-1.0, 1.0)
    ax.set_title("b   Simulation controls", loc="left")
    ax.legend(frameon=False, fontsize=6.8, loc="upper right",
              handlelength=1.0)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
    ax.set_axisbelow(True)

    # ---- (c) pair-level asymmetry against the bootstrap null
    ax = fig.add_subplot(gs[1, 0])
    nm = eaa["nullmax"]
    ax.hist(nm, bins=24, color="#dfe6ee", edgecolor=BLUE, linewidth=0.7,
            zorder=2)
    p95 = float(np.percentile(nm, 95))
    ax.axvline(p95, color=MUTED, lw=1.1, ls=(0, (4, 2)), zorder=3)
    ax.axvline(eaa["obs_max"], color=RED, lw=1.8, zorder=4)
    ax.annotate(f"observed\nmax |A| = {eaa['obs_max']:.2f}",
                (eaa["obs_max"], ax.get_ylim()[1] * 0.92),
                textcoords="offset points", xytext=(-6, 0), ha="right",
                va="top", fontsize=6.9, color=RED, weight="bold")
    ax.annotate(f"null 95th pct {p95:.2f}", (p95, ax.get_ylim()[1] * 0.80),
                textcoords="offset points", xytext=(-6, 0), ha="right",
                fontsize=6.8, color=INK2)
    ax.set_xlabel("maximum |A| under a reversible model on the same tree")
    ax.set_ylabel("bootstrap replicates")
    ax.set_title("c   Observed asymmetry against the null", loc="left")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
    ax.set_axisbelow(True)

    # ---- (d) per-column substitution counts
    ax = fig.add_subplot(gs[1, 1])
    sc = eaa["site_counts"]
    ax.hist(sc, bins=np.arange(0, sc.max() + 2) - 0.5, color="#e4ece2",
            edgecolor=GREEN, linewidth=0.7, zorder=2)
    ax.axvline(10, color=RED, lw=1.4, ls=(0, (4, 2)), zorder=4)
    n_ok = int((sc >= 10).sum())
    ax.annotate(f"$\\geq$10 substitutions:\n{n_ok} of {len(sc)} columns",
                (10, ax.get_ylim()[1] * 0.88), textcoords="offset points",
                xytext=(7, 0), ha="left", va="top", fontsize=6.9, color=RED)
    ax.annotate(f"median {int(np.median(sc))}", (np.median(sc), 0),
                textcoords="offset points", xytext=(-16, 8), ha="right",
                fontsize=6.8, color=INK2)
    ax.set_xlabel("substitutions mapped to a column")
    ax.set_ylabel("columns")
    ax.set_xlim(-0.5, min(sc.max(), 45) + 0.5)
    ax.set_title("d   Power per column", loc="left")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=GRID, lw=0.5, zorder=0)
    ax.set_axisbelow(True)

    fig.savefig(path, dpi=400, bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


def main():
    dirpath, outdir = sys.argv[1], sys.argv[2]
    os.makedirs(outdir, exist_ok=True)

    print("recomputing simulation controls ...")
    sim = simulation_controls()
    for d in sim:
        print(f"  {d['label'].replace(chr(10),' '):<28} "
              f"A={d['A']:+.3f}  Tv={d['tv']:+.3f}  subs={d['n_subs']}")

    print("recomputing EAA1 analysis ...")
    eaa = eaa1_analysis(os.path.join(dirpath, "1.fa"))
    print(f"  {eaa['n_seqs']} sequences, {eaa['n_subs']} substitutions, "
          f"{len(eaa['rows'])} pairs tested, {eaa['n_sig']} significant")
    print(f"  observed max |A| = {eaa['obs_max']:.3f}, "
          f"null 95th pct = {np.percentile(eaa['nullmax'],95):.3f}")

    f1 = os.path.join(outdir, "Figure1.png")
    f2 = os.path.join(outdir, "Figure2.png")
    figure1(f1)
    print(f"wrote {f1}")
    figure3(f2, sim, eaa,
            os.path.join(dirpath, "fold_eaa1_trimer_model_0.cif"))
    print(f"wrote {f2}")

    vals = {
        "simulation": {d["label"].replace("\n", " "):
                       {"A": round(d["A"], 3), "tv": round(d["tv"], 3)}
                       for d in sim},
        "eaa1": {
            "n_seqs": eaa["n_seqs"], "n_cols": eaa["n_cols"],
            "n_subs": eaa["n_subs"], "n_pairs_tested": len(eaa["rows"]),
            "n_significant": eaa["n_sig"],
            "obs_max_A": round(eaa["obs_max"], 3),
            "null_95pct": round(float(np.percentile(eaa["nullmax"], 95)), 3),
            "null_mean": round(float(eaa["nullmax"].mean()), 3),
            "median_site_count": int(np.median(eaa["site_counts"])),
            "columns_ge_10": int((eaa["site_counts"] >= 10).sum()),
        },
    }
    jp = os.path.join(outdir, "figure_values.json")
    with open(jp, "w") as fh:
        json.dump(vals, fh, indent=2)
    print(f"wrote {jp}")
    print()
    print("The manuscript carries two figures: Figure 1 (concept and workflow)")
    print("and Figure 2 (the EAA1 analysis, drawn by figure3 above). The web")
    print("application is described in text only, because the deployed")
    print("interface does not yet behave as the Implementation section requires.")


if __name__ == "__main__":
    main()

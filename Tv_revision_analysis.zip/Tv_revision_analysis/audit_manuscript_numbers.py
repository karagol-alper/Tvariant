#!/usr/bin/env python3
"""
audit_manuscript_numbers.py

Checks every data-derived number in the manuscript against its source, and
reports PASS or FAIL for each. Run it before submission, and again after any
change to the alignment, the variant table or the pipeline.

It exists because a revision that corrects someone else's unverified numbers
has no business carrying unverified numbers of its own.

Usage:
  python3 -I audit_manuscript_numbers.py <manuscript.docx> <EAA1_dir> [run.log]

<EAA1_dir> must contain 1.fa, the gnomAD CSV, and
tv_analysis_complete_*/high_tension_sites_*.csv
"""

import csv
import glob
import math
import os
import re
import sys
from collections import Counter

AA = set("ACDEFGHIKLMNPQRSTVWY")
RESULTS = []


def check(label, expected, actual, tol=None, note=""):
    if tol is None:
        ok = (expected == actual)
    else:
        try:
            ok = abs(float(expected) - float(actual)) <= tol
        except (TypeError, ValueError):
            ok = False
    RESULTS.append(ok)
    tag = "PASS" if ok else "FAIL"
    line = f"[{tag}] {label}"
    print(line)
    print(f"        manuscript: {expected}    source: {actual}"
          + (f"    {note}" if note else ""))
    return ok


def read_fasta(path):
    seqs, name, buf = [], None, []
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.rstrip()
        if line.startswith(">"):
            if name is not None:
                seqs.append((name, "".join(buf)))
            name, buf = line[1:], []
        else:
            buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def doc_text(path):
    import docx
    d = docx.Document(path)
    ps = [p.text for p in d.paragraphs]
    try:
        ref = next(i for i, t in enumerate(ps) if t.strip() == "References")
    except StopIteration:
        ref = len(ps)
    return " ".join(ps[:ref])


def main():
    doc_path, dirpath = sys.argv[1], sys.argv[2]
    log_path = sys.argv[3] if len(sys.argv) > 3 else None
    text = doc_text(doc_path)

    recs = read_fasta(os.path.join(dirpath, "1.fa"))
    msa = [s for _, s in recs]
    names = [n for n, _ in recs]
    n, L = len(msa), min(len(s) for s in msa)

    def column(pos):
        c, g = Counter(), 0
        for s in msa:
            a = s[pos].upper()
            if a in AA:
                c[a] += 1
            else:
                g += 1
        return c, g

    def bits(c):
        v = sum(c.values())
        return -sum((x / v) * math.log2(x / v + 1e-6) for x in c.values()) if v else 0.0

    def claims(pattern):
        """Numbers the manuscript states, by regex group."""
        m = re.search(pattern, text)
        return m.groups() if m else None

    print("=" * 74)
    print("ALIGNMENT")
    print("=" * 74)
    c = claims(r"comprises (\d+)\s+sequences of length (\d+) columns, representing "
               r"(\d+) distinct species labels")
    if c:
        check("sequence count", int(c[0]), n)
        check("alignment length", int(c[1]), L)
        sp = Counter(m.group(1) for nm in names
                     for m in [re.search(r"\[([^\]]+)\]", nm)] if m)
        check("distinct species labels", int(c[2]), len(sp))
    else:
        print("  (alignment sentence not found; skipping)")

    c = claims(r"positions 531 to\s*(\d+) contain (\d+) to (\d+) gaps, "
               r"corresponding to (\d+(?:\.\d+)?) to (\d+(?:\.\d+)?) per cent")
    if c:
        gaps = [column(p - 1)[1] for p in (531, 532, 533)]
        check("gap count range at 531-533", f"{c[1]}-{c[2]}",
              f"{min(gaps)}-{max(gaps)}")
        check("gap percentage range", f"{c[3]}-{c[4]}",
              f"{min(gaps)/n*100:.1f}-{max(gaps)/n*100:.1f}")

    nogap = [12, 99, 142, 186, 219, 294, 336, 337, 428, 429, 430]
    bad = [p for p in nogap if column(p - 1)[1] > 0]
    check("listed positions contain no gaps", "none", bad or "none")

    print()
    print("=" * 74)
    print("POSITIONAL ENTROPIES (bits)")
    print("=" * 74)
    for pos, pat in [
        (219, r"Shannon entropy (\d+(?:\.\d+)?) bits and no gaps, and the substitution"),
        (99, r"entropy (\d+(?:\.\d+)?) bits at position 99"),
        (12, r"(\d+(?:\.\d+)?) bits at position 12"),
        (186, r"Shannon entropy (\d+(?:\.\d+)?) bits and no gaps\. Cysteine"),
    ]:
        m = re.search(pat, text)
        if m:
            check(f"entropy at position {pos}", m.group(1),
                  f"{bits(column(pos-1)[0]):.2f}", tol=0.005)

    print()
    print("=" * 74)
    print("RESIDUE COMPOSITION")
    print("=" * 74)
    m = re.search(r"rarest residue in this alignment at (\d+(?:\.\d+)?) per cent", text)
    if m:
        tot = Counter()
        for j in range(L):
            for s in msa:
                a = s[j].upper()
                if a in AA:
                    tot[a] += 1
        T = sum(tot.values())
        check("cysteine frequency", m.group(1), f"{tot['C']/T*100:.2f}", tol=0.005)

    print()
    print("=" * 74)
    print("PUBLISHED Tv SITE TABLE")
    print("=" * 74)
    hits = glob.glob(os.path.join(dirpath, "tv_analysis_complete_*",
                                  "high_tension_sites_*.csv"))
    if hits:
        rows = list(csv.DictReader(open(hits[0], encoding="utf-8-sig")))
        mv = [float(r["max_tv"]) for r in rows]
        m = re.search(r"values between (\d+(?:\.\d+)?) and (\d+(?:\.\d+)?)", text)
        if m:
            check("max_tv lower bound", m.group(1), f"{min(mv):.2f}", tol=0.005)
            check("max_tv upper bound", m.group(2), f"{max(mv):.2f}", tol=0.005)

    print()
    print("=" * 74)
    print("VARIANT TABLE")
    print("=" * 74)
    gfiles = glob.glob(os.path.join(dirpath, "gnomAD_*.csv"))
    if gfiles:
        g = list(csv.DictReader(open(gfiles[0], encoding="utf-8-sig")))
        m = re.search(r"gnomAD v4\.1\.0, giving (\d+) entries", text)
        if m:
            check("gnomAD entry count", int(m.group(1)), len(g))
        cc = Counter((r.get("ClinVar Germline Classification") or "(none)")
                     for r in g)
        m = re.search(r"(\d+) entries carry no classification, (\d+) are of "
                      r"uncertain significance, (\d+) likely benign, (\d+) of "
                      r"conflicting classification, (\d+) benign, (\d+) benign or "
                      r"likely benign, and (\d+) pathogenic", text)
        if m:
            want = [int(x) for x in m.groups()]
            got = [cc.get("(none)", 0),
                   cc.get("Uncertain significance", 0),
                   cc.get("Likely benign", 0),
                   cc.get("Conflicting classifications of pathogenicity", 0),
                   cc.get("Benign", 0),
                   cc.get("Benign/Likely benign", 0),
                   cc.get("Pathogenic", 0)]
            check("ClinVar classification counts", want, got)

        def variant(tag):
            return [r for r in g if tag in (r.get("Protein Consequence") or "")]

        m = re.search(r"allele frequency of (\d+(?:\.\d+)?) per cent \(([\d,]+) of "
                      r"([\d,]+) alleles\)", text)
        if m:
            r = variant("Glu219Asp")[0]
            check("E219D allele count", m.group(2).replace(",", ""),
                  r["Allele Count"])
            check("E219D allele number", m.group(3).replace(",", ""),
                  r["Allele Number"])
            check("E219D allele frequency (%)", m.group(1),
                  f"{float(r['Allele Frequency'])*100:.2f}", tol=0.005)

        for tag, pat in [("Leu99His", r"frequencies of\s*(\d+(?:\.\d+)?) × 10−7"),
                         ("Cys186Ser", r"allele frequency of\s*(\d+(?:\.\d+)?) × 10−7")]:
            m = re.search(pat, text)
            if m:
                af = float(variant(tag)[0]["Allele Frequency"])
                check(f"{tag} allele frequency (x10^-7)", m.group(1),
                      f"{af*1e7:.2f}", tol=0.005)

    if log_path and os.path.exists(log_path):
        print()
        print("=" * 74)
        print("POLARISED RUN")
        print("=" * 74)
        log = open(log_path, encoding="utf-8").read()

        def from_log(pat, cast=str):
            mm = re.search(pat, log)
            return cast(mm.group(1)) if mm else None

        pairs = [
            (r"on which ([\d,]+) substitutions were mapped",
             r"substitutions mapped: (\d+)", "substitutions mapped"),
            (r"kept (\d+)", r"kept (\d+)", "sequences kept"),
            (r"(\d+) carried at least ten events",
             r"0 of (\d+) tested pairs", "pairs tested"),
            (r"only (\d+)\s*of 544 columns carry ten or more",
             r"columns with at least 10 substitutions: (\d+)", "columns >=10 subs"),
        ]
        for doc_pat, log_pat, label in pairs:
            md = re.search(doc_pat, text)
            ml = re.search(log_pat, log)
            if md and ml:
                check(label, md.group(1).replace(",", ""), ml.group(1))

        for doc_pat, log_pat, label, tol in [
            (r"empirical p of (\d+(?:\.\d+)?)", r"empirical p = (\d+(?:\.\d+)?)",
             "bootstrap empirical p", 0.005),
            (r"95th percentile (\d+(?:\.\d+)?)", r"95th pct (\d+(?:\.\d+)?)",
             "bootstrap 95th percentile", 0.005),
            (r"Tᵥ log-ratio is \+(\d+(?:\.\d+)?)",
             r"Tv log-ratio: \+(\d+(?:\.\d+)?)", "correlation with Tv", 0.005),
        ]:
            md = re.search(doc_pat, text)
            ml = re.search(log_pat, log)
            if md and ml:
                check(label, md.group(1), f"{float(ml.group(1)):.2f}", tol=tol)

    # ---- figures: embedded, and drawn from the same values as the text
    print()
    print("=" * 74)
    print("FIGURES")
    print("=" * 74)
    import zipfile
    media = [n for n in zipfile.ZipFile(doc_path).namelist()
             if n.startswith("word/media/")]
    check("embedded figure images", 2, len(media),
          note="Figure 1 (concept) and Figure 2 (EAA1 analysis)")

    fv_path = os.path.join(os.path.dirname(os.path.abspath(doc_path)),
                           "figures", "figure_values.json")
    if os.path.exists(fv_path):
        import json
        fv = json.load(open(fv_path))
        sim = fv["simulation"]

        def sim_lookup(*needles):
            """Match a simulation entry however its label is spelled."""
            for k, v in sim.items():
                kl = k.lower().replace(",", "").replace("\n", " ")
                if all(nd in kl for nd in needles):
                    return v
            raise KeyError(needles)
        m = re.search(r"the mean A on the generating pairs was \+(\d+\.\d+)", text)
        if m:
            check("Fig 2b forward vs text", m.group(1),
                  f"{sim_lookup('non-reversible','forward')['A']:.3f}", tol=0.0005)
        m = re.search(r"changed the mean to −(\d+\.\d+)", text)
        if m:
            check("Fig 2b reversed vs text", m.group(1),
                  f"{abs(sim_lookup('non-reversible','reversed')['A']):.3f}",
                  tol=0.0005)
        e = fv["eaa1"]
        m = re.search(r"an observed maximum of (\d+\.\d+)", text)
        if m:
            check("Fig 2c observed max vs text", m.group(1),
                  f"{e['obs_max_A']:.2f}", tol=0.005)
        m = re.search(r"95th percentile (\d+\.\d+)", text)
        if m:
            check("Fig 2c null 95th pct vs text", m.group(1),
                  f"{e['null_95pct']:.2f}", tol=0.005)
        m = re.search(r"only (\d+)\s*of 544 columns carry ten or more", text)
        if m:
            check("Fig 2d columns >=10 vs text", int(m.group(1)),
                  e["columns_ge_10"])
    else:
        print("  (figures/figure_values.json not found; run make_figures.py)")

    print()
    print("=" * 74)
    npass, ntot = sum(RESULTS), len(RESULTS)
    print(f"{npass} of {ntot} checks passed")
    print("=" * 74)
    sys.exit(0 if npass == ntot else 1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
diagnose_direction_artefact.py

Establishes what the 'direction' column of the high-tension site table is
actually reporting, and tests the gap/entropy confound raised for position 12
and the C-terminal positions.

Usage:
  python3 -I diagnose_direction_artefact.py <alignment.fa> <published_sites.csv>
"""

import csv
import math
import sys
from collections import Counter

AA = ["A", "R", "N", "D", "C", "Q", "E", "G", "H", "I",
      "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V"]
AASET = set(AA)
WINDOW = 3


def read_fasta(path):
    seqs, name, buf = [], None, []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:], []
            else:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def col_counts(msa, pos):
    c = Counter()
    gaps = 0
    for s in msa:
        a = s[pos].upper()
        if a in AASET:
            c[a] += 1
        else:
            gaps += 1
    return c, gaps


def entropy_nongap(counts):
    """Shannon entropy over non-gap residues only, as the shipped code does."""
    tot = sum(counts.values())
    if tot == 0:
        return 0.0
    h = 0.0
    for n in counts.values():
        p = n / tot
        h -= p * math.log(p + 1e-6)
    return h


def entropy_with_gaps(counts, gaps):
    """Shannon entropy treating the gap as a 21st character."""
    tot = sum(counts.values()) + gaps
    if tot == 0:
        return 0.0
    h = 0.0
    for n in list(counts.values()) + ([gaps] if gaps else []):
        p = n / tot
        h -= p * math.log(p + 1e-6)
    return h


def main():
    fa, pub = sys.argv[1], sys.argv[2]
    msa = [s for _, s in read_fasta(fa)]
    L = min(len(s) for s in msa)
    msa = [s[:L] for s in msa]
    n = len(msa)

    published = []
    with open(pub, encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            published.append((int(row["position"]), float(row["max_tv"]),
                              row["direction"]))

    print("=" * 78)
    print("PART 1  what the reported 'direction' tracks")
    print("=" * 78)
    print()
    print("For each published site, the residues absent from EVERY column of the")
    print("smoothing window are mutually tied at the maximum after smoothing.")
    print("The strict '>' argmax returns the first of them in the hard-coded")
    print("array order ARNDCQEGHILKMFPSTWYV.")
    print()
    hdr = f"{'pos':>5} {'dir':<6} {'target':<7} {'absent across window':<26} {'first in array order':<20}"
    print(hdr)
    print("-" * len(hdr))
    correct = 0
    for pos, _, direction in published:
        i = pos - 1
        start, end = max(0, i - WINDOW), min(L - 1, i + WINDOW)
        absent_all = []
        for a in AA:
            if all(col_counts(msa, j)[0].get(a, 0) == 0 for j in range(start, end + 1)):
                absent_all.append(a)
        first = absent_all[0] if absent_all else "-"
        target = direction.split("→")[1]
        ok = (first == target)
        correct += ok
        print(f"{pos:>5} {direction:<6} {target:<7} "
              f"{','.join(absent_all) if absent_all else '(none)':<26} "
              f"{first:<20} {'MATCH' if ok else ''}")
    print()
    print(f"the reported target residue is the first array-order residue absent")
    print(f"across the whole smoothing window in {correct} of {len(published)} sites")
    print()
    print("Cysteine and aspartate are the rarest residues in this alignment, so")
    print("they are the ones most often absent from an entire 7-column window.")
    print("Reordering the AMINO_ACIDS array would change every reported direction")
    print("without touching the data.")
    print()

    # residue-level rarity, to make the point concrete
    overall = Counter()
    for j in range(L):
        overall.update(col_counts(msa, j)[0])
    tot = sum(overall.values())
    rare = sorted(AA, key=lambda a: overall.get(a, 0))
    print("overall residue frequencies in the alignment (rarest first):")
    print("  " + ", ".join(f"{a}={overall.get(a,0)/tot*100:.2f}%" for a in rare[:6]))
    print()

    print("=" * 78)
    print("PART 2  the gap / entropy confound")
    print("=" * 78)
    print()
    print("The shipped code normalises column frequencies over non-gap residues")
    print("only (count / validCount), so a column that is mostly gaps but")
    print("invariant among the few residues present is scored as fully conserved.")
    print()
    hdr2 = (f"{'pos':>5} {'gaps':>6} {'gap%':>7} {'non-gap':>8} "
            f"{'H(non-gap)':>11} {'H(with gaps)':>13}")
    print(hdr2)
    print("-" * len(hdr2))
    watch = [12, 99, 186, 219] + [p for p, _, _ in published]
    seen = set()
    for pos in sorted(set(watch)):
        if pos - 1 >= L or pos in seen:
            continue
        seen.add(pos)
        c, gaps = col_counts(msa, pos - 1)
        nongap = sum(c.values())
        print(f"{pos:>5} {gaps:>6} {gaps/n*100:>6.1f}% {nongap:>8} "
              f"{entropy_nongap(c):>11.3f} {entropy_with_gaps(c, gaps):>13.3f}")
    print()

    # how many columns are gap-dominated yet scored as conserved?
    flagged = 0
    for j in range(L):
        c, gaps = col_counts(msa, j)
        if gaps / n > 0.5 and entropy_nongap(c) < 0.5:
            flagged += 1
    print(f"columns that are >50% gaps yet have non-gap entropy < 0.5: {flagged}")
    print("These are scored as highly conserved on the strength of a small number")
    print("of aligned residues, and are exactly the columns where a high-tension")
    print("call is least trustworthy.")
    print()

    print("=" * 78)
    print("PART 3  alignment composition")
    print("=" * 78)
    print()
    names = [nm for nm, _ in read_fasta(fa)]
    import re
    para = {
        "EAAT2 / SLC1A2": r"amino acid transporter 2|SLC1A2|EAAT2|GLT-1",
        "EAAT3 / SLC1A1": r"amino acid transporter 3|SLC1A1|EAAT3|EAAC1",
        "EAAT4 / SLC1A6": r"amino acid transporter 4|SLC1A6|EAAT4",
        "EAAT5 / SLC1A7": r"amino acid transporter 5|SLC1A7|EAAT5",
        "ASCT1/2 / SLC1A4-5": r"neutral amino acid transporter|SLC1A4|SLC1A5|ASCT",
    }
    for label, pat in para.items():
        hits = [nm for nm in names if re.search(pat, nm, re.I)]
        print(f"  {label:<22} {len(hits):>4} sequences")
        for h in hits[:2]:
            print(f"      {h[:92]}")
    print()
    species = Counter()
    for nm in names:
        m = re.search(r"\[([^\]]+)\]", nm)
        if m:
            species[m.group(1)] += 1
    print(f"  distinct species labels: {len(species)}")
    print(f"  sequences per species, most frequent: "
          f"{', '.join(f'{s}={c}' for s, c in species.most_common(4))}")
    print()
    print("  Paralogue content and species redundancy both need to be reported,")
    print("  and sequence weighting applied, before column frequencies can be")
    print("  read as substitution propensities.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
verify_tv_properties.py

Analytical and numerical audit of the Directional Variant Tension (Tv) estimator
exactly as defined in the manuscript:

  Eq. 26  p_i(Y|X) = [ sum_Z K_s(f_i(X), f_i(Z)) * I[Z=Y] ] / [ sum_Z K_s(f_i(X), f_i(Z)) ]
  Eq. 27  K_s(u,v) = exp( -(u-v)^2 / (2 s^2) )
  Eq. 32  Tv_i(X->Y) = [ p_i(Y|X) / p_i(X|Y) ] * H_i^-1 / Z
  Eq. 33  Z = sum_{X!=Y} [ p_i(Y|X) / p_i(X|Y) ] * H_i^-1

Tests
  1  R(X->Y) == S(Y)/S(X), where S(X) = sum_Z K_s(f(X), f(Z))   [kernel cancels]
  2  Tv is a function of the column frequency vector alone: identical frequency
     vectors with opposite true substitution histories give identical Tv
  3  max R at a column equals the number of absent residues (the "ceiling ~20")
  4  the 1/H weight cancels under the stated normalisation
  5  R(Y->X) == 1/R(X->Y) holds identically for every column
  6  R(X->Y1) == R(X->Y2) whenever Y1, Y2 are both absent (tie / argmax order)
  7  a process and its exact reverse give the same Tv distribution
  8  max Tv vs Shannon entropy and vs number of distinct residues

Usage:  python3 -I verify_tv_properties.py
"""

import numpy as np

AA = list("ACDEFGHIKLMNPQRSTVWY")
NA = len(AA)
IDX = {a: i for i, a in enumerate(AA)}
rng = np.random.default_rng(20261108)

SIGMA = 0.10          # manuscript default
PSEUDO = 0.01         # manuscript Dirichlet pseudocount
EPS = 1e-6            # manuscript epsilon in the entropy


# ----------------------------------------------------------------------
# estimator, implemented verbatim from the manuscript
# ----------------------------------------------------------------------

def freqs(column, pseudo=PSEUDO):
    """Empirical marginal frequency vector p_i(X) with Dirichlet pseudocount."""
    counts = np.zeros(NA)
    for c in column:
        if c in IDX:
            counts[IDX[c]] += 1.0
    return (counts + pseudo) / (counts.sum() + NA * pseudo)


def entropy(f, eps=EPS):
    """Eq. 18: H_i = -sum_X p(X) log(p(X) + eps)."""
    return float(-np.sum(f * np.log(f + eps)))


def kernel_matrix(f, sigma=SIGMA):
    """K[a,b] = K_sigma(f(a), f(b))."""
    d = f[:, None] - f[None, :]
    return np.exp(-(d ** 2) / (2.0 * sigma ** 2))


def cond_prob_matrix(f, sigma=SIGMA):
    """Eq. 26 as written: P[x,y] = p(Y=y | X=x)."""
    K = kernel_matrix(f, sigma)
    # numerator: I[Z=Y] collapses the sum to the single term K(f(X), f(Y))
    num = K
    den = K.sum(axis=1, keepdims=True)
    return num / den


def R_matrix(f, sigma=SIGMA):
    """R[x,y] = p(Y|X) / p(X|Y) for the ordered pair X->Y."""
    P = cond_prob_matrix(f, sigma)
    return P / P.T


def S_vector(f, sigma=SIGMA):
    """S(X) = sum_Z K_sigma(f(X), f(Z))."""
    return kernel_matrix(f, sigma).sum(axis=1)


def tv_matrix(f, sigma=SIGMA, normalise=True):
    """Eq. 32/33. Returns the normalised tension matrix for one column."""
    R = R_matrix(f, sigma)
    H = entropy(f)
    W = R / H                                    # R * H^-1
    if not normalise:
        return W
    off = ~np.eye(NA, dtype=bool)
    Z = W[off].sum()                             # Eq. 33, sum over X != Y
    return W / Z


def report(name, passed, detail=""):
    tag = "CONFIRMED" if passed else "NOT CONFIRMED"
    print(f"[{tag}] {name}")
    if detail:
        for line in detail.rstrip().splitlines():
            print(f"            {line}")
    print()
    return passed


# ----------------------------------------------------------------------
# Test 1 - the Gaussian kernel cancels; R depends only on marginals
# ----------------------------------------------------------------------

def test_kernel_cancellation():
    worst = 0.0
    for _ in range(300):
        k = rng.integers(1, 8)
        col = rng.choice(AA, size=k).tolist() * rng.integers(1, 20)
        col = (col + rng.choice(AA, size=rng.integers(0, 30)).tolist())
        f = freqs(col)
        R = R_matrix(f)
        S = S_vector(f)
        predicted = S[None, :] / S[:, None]      # S(Y)/S(X)
        worst = max(worst, float(np.max(np.abs(R - predicted))))
    return report(
        "Test 1  R(X->Y) reduces exactly to S(Y)/S(X); the kernel term cancels",
        worst < 1e-9,
        f"max |R - S(Y)/S(X)| over 300 random columns = {worst:.3e}\n"
        "Consequence: R is a ratio of two scalar summaries of the frequency\n"
        "vector. It contains no pairwise substitution information whatsoever.",
    )


# ----------------------------------------------------------------------
# Test 2 - direction-blindness with matched frequencies
# ----------------------------------------------------------------------

def test_direction_blindness():
    # Column A: ancestral I, ten I->W substitutions occurred.
    # Column B: ancestral W, ten W->I substitutions occurred.
    # Identical frequency vectors, exactly opposite true histories.
    colA = ["I"] * 10 + ["W"] * 10
    colB = ["W"] * 10 + ["I"] * 10
    fA, fB = freqs(colA), freqs(colB)
    TA, TB = tv_matrix(fA), tv_matrix(fB)
    i, w = IDX["I"], IDX["W"]
    same = np.allclose(TA, TB, atol=1e-12)
    return report(
        "Test 2  identical frequencies + opposite true direction -> identical Tv",
        same,
        f"column A (true direction I->W):  Tv(I->W) = {TA[i, w]:.6e}   "
        f"Tv(W->I) = {TA[w, i]:.6e}\n"
        f"column B (true direction W->I):  Tv(I->W) = {TB[i, w]:.6e}   "
        f"Tv(W->I) = {TB[w, i]:.6e}\n"
        f"max |Tv_A - Tv_B| = {np.max(np.abs(TA - TB)):.3e}\n"
        "The estimator cannot distinguish a substitution from its reverse.",
    )


# ----------------------------------------------------------------------
# Test 3 - the ceiling equals the number of absent residues
# ----------------------------------------------------------------------

def test_ceiling():
    rows = []
    for n_distinct in (1, 2, 3, 4, 5, 8, 10):
        present = AA[:n_distinct]
        col = []
        for a in present:
            col += [a] * (100 // n_distinct)
        f = freqs(col)
        R = R_matrix(f)
        off = ~np.eye(NA, dtype=bool)
        rows.append((n_distinct, NA - n_distinct, float(R[off].max()), entropy(f)))

    conserved_max = rows[0][2]
    maxima = [r[2] for r in rows]
    monotone = all(a >= b - 1e-9 for a, b in zip(maxima, maxima[1:]))
    exact_ceiling = abs(conserved_max - (NA - 1)) < 1e-6

    detail = ["n_distinct  n_absent   max R      H"]
    for nd, na_, mr, H in rows:
        detail.append(f"{nd:>9}  {na_:>8}  {mr:>7.3f}  {H:>5.3f}")
    detail += [
        "",
        f"A perfectly conserved column gives max R = {conserved_max:.3f}, i.e. exactly",
        f"|A| - 1 = {NA - 1}: the self-kernel of the consensus residue (S = 1) against",
        "the 19 mutually indistinguishable absent residues (S = 19).",
        "max R then falls monotonically as the column becomes more variable, so the",
        "values 'near 20' at the top of Table 1 are the alphabet size reached at",
        "maximally conserved columns, not a property of any substitution.",
    ]
    return report(
        "Test 3  the Table 1 ceiling is |A|-1, attained at conserved columns",
        exact_ceiling and monotone, "\n".join(detail),
    )


# ----------------------------------------------------------------------
# Test 4 - the 1/H weight cancels
# ----------------------------------------------------------------------

def test_entropy_cancels():
    worst = 0.0
    for _ in range(200):
        col = rng.choice(AA, size=rng.integers(20, 200)).tolist()
        f = freqs(col)
        with_H = tv_matrix(f, normalise=True)
        # same thing with the 1/H weight simply omitted
        R = R_matrix(f)
        off = ~np.eye(NA, dtype=bool)
        without_H = R / R[off].sum()
        worst = max(worst, float(np.max(np.abs(with_H - without_H))))
    return report(
        "Test 4  the inverse-entropy weight cancels under the stated normalisation",
        worst < 1e-12,
        f"max |Tv(with 1/H) - Tv(without 1/H)| = {worst:.3e}\n"
        "H_i^-1 is a per-position scalar present in both Eq. 32 and Eq. 33,\n"
        "so it divides out. The stated entropy weighting has no effect.\n"
        "The normalised values also sum to 1 over the 380 ordered pairs, so they\n"
        "cannot reach 4.80, 10.36 or 19; the reported numbers are unnormalised R.",
    )


# ----------------------------------------------------------------------
# Test 5 - the consistency check is an identity
# ----------------------------------------------------------------------

def test_consistency_identity():
    worst = 0.0
    for _ in range(200):
        col = rng.choice(AA, size=rng.integers(20, 200)).tolist()
        R = R_matrix(freqs(col))
        off = ~np.eye(NA, dtype=bool)
        worst = max(worst, float(np.max(np.abs((R * R.T)[off] - 1.0))))
    return report(
        "Test 5  R(Y->X) = 1/R(X->Y) is an algebraic identity, not a check",
        worst < 1e-9,
        f"max |R(X->Y)*R(Y->X) - 1| = {worst:.3e}\n"
        "This holds for every column and every pair by construction, so it can\n"
        "never fail and provides no validation of anything.",
    )


# ----------------------------------------------------------------------
# Test 6 - absent residues tie exactly
# ----------------------------------------------------------------------

def test_ties():
    col = ["I"] * 98 + ["V"] * 2          # C and W both absent
    f = freqs(col)
    R = R_matrix(f)
    i, c, w = IDX["I"], IDX["C"], IDX["W"]
    tie = abs(R[i, c] - R[i, w])
    off = ~np.eye(NA, dtype=bool)
    maxR = R[off].max()
    winners = [f"{AA[a]}->{AA[b]}" for a, b in zip(*np.where(np.isclose(R, maxR)))]
    return report(
        "Test 6  all absent residues are exactly tied; the winner is arbitrary",
        tie < 1e-12,
        f"R(I->C) = {R[i, c]:.6f}   R(I->W) = {R[i, w]:.6f}   "
        f"difference = {tie:.3e}\n"
        f"number of ordered pairs tied at the maximum: {len(winners)}\n"
        f"first few: {', '.join(winners[:6])}\n"
        "argmax therefore returns whichever tied residue comes first in the\n"
        "iteration order. With the standard ordering ACDEFGHIKLMNPQRSTVWY and A\n"
        "usually present at low frequency, C is routinely the first absent\n"
        "residue - which is why Table 1 is dominated by '->C'. Permuting the\n"
        "alphabet order changes the reported hits without changing the data.",
    )


# ----------------------------------------------------------------------
# Test 7 - a process and its exact reverse are indistinguishable
# ----------------------------------------------------------------------

def simulate_columns(Q, n_cols, n_tips=64, branch=0.08, seed=0):
    """Simulate alignment columns down a balanced tree under rate matrix Q.

    Returns (columns, net_flux) where net_flux[x,y] counts realised x->y
    substitutions minus y->x substitutions, summed over branches.
    """
    from scipy.linalg import expm
    r = np.random.default_rng(seed)
    P = expm(Q * branch)
    P = P / P.sum(axis=1, keepdims=True)
    cum = np.cumsum(P, axis=1)
    pi = np.ones(NA) / NA
    cols, flux = [], np.zeros((NA, NA))

    def descend(state, depth, tips):
        if depth == 0:
            tips.append(state)
            return
        for _ in range(2):
            u = r.random()
            child = int(np.searchsorted(cum[state], u))
            if child != state:
                flux[state, child] += 1
                flux[child, state] -= 1
            descend(child, depth - 1, tips)

    depth = int(np.log2(n_tips))
    for _ in range(n_cols):
        root = int(r.choice(NA, p=pi))
        tips = []
        descend(root, depth, tips)
        cols.append([AA[s] for s in tips])
    return cols, flux


def directed_cycle_Q(rate=1.0, reverse=False):
    """Strictly non-reversible generator: a directed cycle through the alphabet."""
    Q = np.zeros((NA, NA))
    for a in range(NA):
        b = (a + 1) % NA
        if reverse:
            Q[b, a] = rate
        else:
            Q[a, b] = rate
    np.fill_diagonal(Q, -Q.sum(axis=1))
    return Q


def test_process_reversal():
    """Two complementary checks against simulated ground truth.

    (a) does Tv correlate with the realised net substitution flux at all?
    (b) when the generating process is replaced by its exact reverse, so that
        the true flux flips sign, does Tv follow?
    """
    n_cols = 400
    colsF, fluxF = simulate_columns(directed_cycle_Q(), n_cols, seed=1)
    colsR, fluxR = simulate_columns(directed_cycle_Q(reverse=True), n_cols, seed=1)

    def mean_log_R(cols):
        acc = np.zeros((NA, NA))
        for c in cols:
            acc += np.log(R_matrix(freqs(c)))
        return acc / len(cols)

    LF, LR = mean_log_R(colsF), mean_log_R(colsR)
    off = ~np.eye(NA, dtype=bool)

    # (a) recovery of direction within one simulation
    r_recover = float(np.corrcoef(LF[off], fluxF[off])[0, 1])
    # (b) response to reversing the generating process
    r_truth_flip = float(np.corrcoef(fluxF[off], fluxR[off])[0, 1])
    r_tv_flip = float(np.corrcoef(LF[off], LR[off])[0, 1])

    recovers_nothing = abs(r_recover) < 0.2
    fails_to_flip = r_tv_flip > -0.2

    return report(
        "Test 7  Tv neither recovers true direction nor responds to reversing it",
        recovers_nothing and fails_to_flip and r_truth_flip < -0.5,
        f"(a) mean log R vs realised net flux, same simulation:  r = {r_recover:+.3f}\n"
        "    A direction-sensitive statistic would be strongly positive here.\n"
        "\n"
        f"(b) true net flux, forward vs reversed process:        r = {r_truth_flip:+.3f}\n"
        f"    mean log R,  forward vs reversed process:          r = {r_tv_flip:+.3f}\n"
        "    The ground truth flips sign as designed; Tv does not follow it, and\n"
        "    in fact stays positively correlated with its own mirror image.\n"
        "\n"
        "Reversing every substitution in the data leaves the metric essentially\n"
        "unchanged, because the two processes have similar marginal frequencies\n"
        "and the marginals are all Tv can see.",
    )


# ----------------------------------------------------------------------
# Test 8 - Tv vs entropy and residue count
# ----------------------------------------------------------------------

def test_permutation_invariance():
    """Tv is invariant to any reshuffling of residues across sequences.

    Shuffling a column across tips destroys every trace of phylogenetic
    structure, and therefore all information about which residue was ancestral.
    Tv is unchanged, which bounds what it can possibly measure.
    """
    cols, _ = simulate_columns(directed_cycle_Q(), 200, branch=0.25, seed=11)
    worst = 0.0
    for c in cols:
        before = tv_matrix(freqs(c))
        shuffled = list(c)
        rng.shuffle(shuffled)
        after = tv_matrix(freqs(shuffled))
        worst = max(worst, float(np.max(np.abs(before - after))))
    return report(
        "Test 8  Tv is invariant to destroying all phylogenetic structure",
        worst < 1e-12,
        f"max |Tv(column) - Tv(shuffled column)| over 200 columns = {worst:.3e}\n"
        "Tv is a function of the column's multiset of residues only. Any statistic\n"
        "with this invariance is blind to ancestry by construction, so no choice\n"
        "of sigma, window or normalisation can make it directional.",
    )


def measure_vs_entropy():
    """Reported as a measurement, not a pass/fail: how much of Tv is conservation?"""
    from scipy.stats import spearmanr
    cols, _ = simulate_columns(directed_cycle_Q(), 600, branch=0.25, seed=7)
    maxtv, H, ndist = [], [], []
    off = ~np.eye(NA, dtype=bool)
    for c in cols:
        f = freqs(c)
        maxtv.append(float(R_matrix(f)[off].max()))
        H.append(entropy(f))
        ndist.append(len(set(c)))
    rho_H = spearmanr(maxtv, H).statistic
    rho_n = spearmanr(maxtv, ndist).statistic
    print("[MEASURED]  max Tv against conservation baselines (600 simulated columns)")
    print(f"            Spearman(max Tv, Shannon entropy)     = {rho_H:+.3f}")
    print(f"            Spearman(max Tv, n distinct residues)  = {rho_n:+.3f}")
    print("            max Tv is substantially but not wholly explained by entropy:")
    print("            it is a different nonlinear summary of the same frequency")
    print("            vector, not a restatement of Shannon entropy specifically.")
    print("            Whether it outperforms entropy as a conservation-like")
    print("            predictor is an empirical question that needs real labelled")
    print("            data; it is not settled by this simulation either way.")
    print()


if __name__ == "__main__":
    print("=" * 74)
    print("Audit of the Tv estimator as defined in Eq. 26-33")
    print(f"sigma = {SIGMA}, pseudocount = {PSEUDO}, |A| = {NA}")
    print("=" * 74)
    print()
    results = [
        test_kernel_cancellation(),
        test_direction_blindness(),
        test_ceiling(),
        test_entropy_cancels(),
        test_consistency_identity(),
        test_ties(),
        test_process_reversal(),
        test_permutation_invariance(),
    ]
    measure_vs_entropy()
    print("=" * 74)
    print(f"{sum(results)} of {len(results)} predictions confirmed")
    print("=" * 74)

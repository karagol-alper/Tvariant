#!/usr/bin/env python3
"""
benchmark_protocol.py

The benchmarking protocol specified in Methods, implemented so that the numbers
in the revision come from the authors' own run rather than from an assertion.

It answers one question: does a candidate site score carry information about
variant effect beyond what positional conservation already provides?

LEVELS OF COMPARISON (following the reviewer's suggestion)

  1  aggregate "to" vector    median score for each target residue, correlated
                              against the same vector from the assay
  2  aggregate "from" vector   median score for each source residue
  3  position level            median over substitutions at each position
  4  variant level             individual substitutions

Aggregate correlations are high for almost any amino acid scale, so entropy and
BLOSUM baselines are computed at every level and reported alongside. The direct
test of added information is the partial correlation of the candidate score with
the assay, controlling for entropy.

CROSS-VALIDATION

Held-out folds are whole genes, never individual variants. Variants within a
gene share an alignment, a structure and a conservation profile, so splitting
variants at random lets information leak between folds and inflates apparent
performance.

DATA

  ProteinGym substitution benchmarks:
      https://proteingym.org/download
      one CSV per assay, columns: mutant, mutated_sequence, DMS_score
  MaveDB:
      https://www.mavedb.org  (API or bulk download)
  ClinVar labels, if used, should be restricted to reviewed two-star-and-above
  assertions.

Alignments for each assayed protein are built by the procedure in Methods and
passed as one FASTA per gene, named <gene>.fa.

USAGE

  python3 -I benchmark_protocol.py \
      --assays proteingym_csvs/ \
      --alignments alignments/ \
      --predictors precomputed_predictors.csv \
      --out benchmark_results

  --predictors is optional: a CSV with columns gene, variant, revel,
  alphamissense, esm1b. Those tools are run separately; this script only
  compares what it is given.
"""

import argparse
import glob
import math
import os
import re
import sys
from collections import defaultdict

import numpy as np

AA = list("ACDEFGHIKLMNPQRSTVWY")
IDX = {a: i for i, a in enumerate(AA)}

# BLOSUM62, standard ordering ARNDCQEGHILKMFPSTWYV mapped onto AA above
_B62_ORDER = list("ARNDCQEGHILKMFPSTWYV")
_B62 = """
 4 -1 -2 -2  0 -1 -1  0 -2 -1 -1 -1 -1 -2 -1  1  0 -3 -2  0
-1  5  0 -2 -3  1  0 -2  0 -3 -2  2 -1 -3 -2 -1 -1 -3 -2 -3
-2  0  6  1 -3  0  0  0  1 -3 -3  0 -2 -3 -2  1  0 -4 -2 -3
-2 -2  1  6 -3  0  2 -1 -1 -3 -4 -1 -3 -3 -1  0 -1 -4 -3 -3
 0 -3 -3 -3  9 -3 -4 -3 -3 -1 -1 -3 -1 -2 -3 -1 -1 -2 -2 -1
-1  1  0  0 -3  5  2 -2  0 -3 -2  1  0 -3 -1  0 -1 -2 -1 -2
-1  0  0  2 -4  2  5 -2  0 -3 -3  1 -2 -3 -1  0 -1 -3 -2 -2
 0 -2  0 -1 -3 -2 -2  6 -2 -4 -4 -2 -3 -3 -2  0 -2 -2 -3 -3
-2  0  1 -1 -3  0  0 -2  8 -3 -3 -1 -2 -1 -2 -1 -2 -2  2 -3
-1 -3 -3 -3 -1 -3 -3 -4 -3  4  2 -3  1  0 -3 -2 -1 -3 -1  3
-1 -2 -3 -4 -1 -2 -3 -4 -3  2  4 -2  2  0 -3 -2 -1 -2 -1  1
-1  2  0 -1 -3  1  1 -2 -1 -3 -2  5 -1 -3 -1  0 -1 -3 -2 -2
-1 -1 -2 -3 -1  0 -2 -3 -2  1  2 -1  5  0 -2 -1 -1 -1 -1  1
-2 -3 -3 -3 -2 -3 -3 -3 -1  0  0 -3  0  6 -4 -2 -2  1  3 -1
-1 -2 -2 -1 -3 -1 -1 -2 -2 -3 -3 -1 -2 -4  7 -1 -1 -4 -3 -2
 1 -1  1  0 -1  0  0  0 -1 -2 -2  0 -1 -2 -1  4  1 -3 -2 -2
 0 -1  0 -1 -1 -1 -1 -2 -2 -1 -1 -1 -1 -2 -1  1  5 -2 -2  0
-3 -3 -4 -4 -2 -2 -3 -2 -2 -3 -2 -3 -1  1 -4 -3 -2 11  2 -3
-2 -2 -2 -3 -2 -1 -2 -3  2 -1 -1 -2 -1  3 -3 -2 -2  2  7 -1
 0 -3 -3 -3 -1 -2 -2 -3 -3  3  1 -2  1 -1 -2 -2  0 -3 -1  4
"""


def blosum62():
    rows = [r.split() for r in _B62.strip().splitlines()]
    M = {}
    for i, a in enumerate(_B62_ORDER):
        for j, b in enumerate(_B62_ORDER):
            M[(a, b)] = float(rows[i][j])
    return M


B62 = blosum62()


def read_fasta(path):
    seqs, name, buf = [], None, []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip()
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:], []
            else:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def column_profile(msa, pos):
    """Frequencies and Shannon entropy in bits over non-gap residues."""
    counts = defaultdict(int)
    valid = 0
    for s in msa:
        if pos >= len(s):
            continue
        a = s[pos].upper()
        if a in IDX:
            counts[a] += 1
            valid += 1
    if valid == 0:
        return {}, 0.0
    f = {a: c / valid for a, c in counts.items()}
    H = -sum(p * math.log2(p + 1e-6) for p in f.values())
    return f, H


def candidate_score(f, src, tgt, sigma=0.1):
    """The frequency-only ratio, as a worked example of a candidate score.

    Replace this function with whatever score is being evaluated. It is kept
    here so the protocol runs end to end on a score whose behaviour is known.
    """
    vec = np.array([f.get(a, 0.0) for a in AA])
    d = vec[:, None] - vec[None, :]
    K = np.exp(-(d ** 2) / (2 * sigma ** 2))
    S = K.sum(axis=1)
    return float(np.log(S[IDX[tgt]] / S[IDX[src]]))


def parse_mutant(token):
    """'A123G' -> ('A', 123, 'G'); returns None if unparseable."""
    m = re.fullmatch(r"([A-Z])(\d+)([A-Z])", token.strip())
    if not m:
        return None
    return m.group(1), int(m.group(2)), m.group(3)


def spearman(x, y):
    from scipy.stats import spearmanr
    if len(x) < 4:
        return float("nan")
    return float(spearmanr(x, y).statistic)


def partial_spearman(x, y, z):
    """Spearman partial correlation of x and y controlling for z."""
    from scipy.stats import rankdata
    if len(x) < 5:
        return float("nan")
    rx, ry, rz = rankdata(x), rankdata(y), rankdata(z)

    def resid(a, b):
        b1 = np.vstack([b, np.ones_like(b)]).T
        coef, *_ = np.linalg.lstsq(b1, a, rcond=None)
        return a - b1 @ coef

    ex, ey = resid(rx, rz), resid(ry, rz)
    if np.std(ex) < 1e-12 or np.std(ey) < 1e-12:
        return float("nan")
    return float(np.corrcoef(ex, ey)[0, 1])


def load_assay(path):
    """ProteinGym-style CSV: columns 'mutant' and 'DMS_score'."""
    import csv
    rows = []
    with open(path, encoding="utf-8-sig") as fh:
        rd = csv.DictReader(fh)
        mut_col = next((c for c in rd.fieldnames
                        if c.lower() in ("mutant", "variant", "mutation")), None)
        score_col = next((c for c in rd.fieldnames
                          if "score" in c.lower()), None)
        if not mut_col or not score_col:
            return []
        for r in rd:
            for token in str(r[mut_col]).split(":"):
                p = parse_mutant(token)
                if p is None:
                    continue
                try:
                    val = float(r[score_col])
                except (TypeError, ValueError):
                    continue
                rows.append((p[0], p[1], p[2], val))
                break
    return rows


def evaluate_gene(gene, assay_rows, msa, offset=0):
    """Score every assayed variant and return per-variant records."""
    recs = []
    for src, pos, tgt, obs in assay_rows:
        col = pos - 1 + offset
        if col < 0:
            continue
        f, H = column_profile(msa, col)
        if not f:
            continue
        # sanity: the alignment's consensus should usually match the wild type
        recs.append({
            "gene": gene, "src": src, "pos": pos, "tgt": tgt,
            "assay": obs,
            "candidate": candidate_score(f, src, tgt),
            "entropy": H,
            "blosum": B62.get((src, tgt), 0.0),
            "wt_match": max(f, key=f.get) == src,
        })
    return recs


def report_levels(recs, label, out):
    def w(line=""):
        print(line)
        out.write(line + "\n")

    if not recs:
        w(f"{label}: no scored variants")
        return

    assay = np.array([r["assay"] for r in recs])
    cand = np.array([r["candidate"] for r in recs])
    ent = np.array([r["entropy"] for r in recs])
    blo = np.array([r["blosum"] for r in recs])

    w(f"\n{label}  (n = {len(recs)} variants, "
      f"{len({r['gene'] for r in recs})} genes)")
    w(f"  wild-type residue matches alignment consensus in "
      f"{100 * np.mean([r['wt_match'] for r in recs]):.1f}% of variants")

    # level 4: variant level
    w("\n  level 4  variant level")
    w(f"    candidate vs assay            rho = {spearman(cand, assay):+.3f}")
    w(f"    entropy   vs assay            rho = {spearman(ent, assay):+.3f}")
    w(f"    BLOSUM62  vs assay            rho = {spearman(blo, assay):+.3f}")
    w(f"    candidate vs assay | entropy  rho = "
      f"{partial_spearman(cand, assay, ent):+.3f}   <- added information")

    # level 3: position level
    bypos = defaultdict(list)
    for r in recs:
        bypos[(r["gene"], r["pos"])].append(r)
    pa, pc, pe = [], [], []
    for k, group in bypos.items():
        pa.append(np.median([g["assay"] for g in group]))
        pc.append(np.median([g["candidate"] for g in group]))
        pe.append(group[0]["entropy"])
    w(f"\n  level 3  position level (n = {len(pa)} positions)")
    w(f"    candidate vs assay            rho = {spearman(pc, pa):+.3f}")
    w(f"    entropy   vs assay            rho = {spearman(pe, pa):+.3f}")
    w(f"    candidate vs assay | entropy  rho = "
      f"{partial_spearman(np.array(pc), np.array(pa), np.array(pe)):+.3f}")

    # levels 1 and 2: aggregate vectors
    for key, name in (("tgt", "level 1  aggregate 'to' residue"),
                      ("src", "level 2  aggregate 'from' residue")):
        agg = defaultdict(list)
        for r in recs:
            agg[r[key]].append(r)
        resid = sorted(agg)
        va = [np.median([g["assay"] for g in agg[a]]) for a in resid]
        vc = [np.median([g["candidate"] for g in agg[a]]) for a in resid]
        vb = [np.median([g["blosum"] for g in agg[a]]) for a in resid]
        w(f"\n  {name} (n = {len(resid)} residues)")
        w(f"    candidate vs assay            rho = {spearman(vc, va):+.3f}")
        w(f"    BLOSUM62  vs assay            rho = {spearman(vb, va):+.3f}")
        w("    NOTE: aggregate correlations are high for almost any amino acid")
        w("    scale; read them only against the BLOSUM baseline on the line above.")


def gene_held_out_cv(recs, out):
    """Leave-one-gene-out: does the candidate beat entropy on unseen genes?"""
    def w(line=""):
        print(line)
        out.write(line + "\n")

    genes = sorted({r["gene"] for r in recs})
    if len(genes) < 3:
        w("\ngene-held-out cross-validation: needs at least 3 genes, skipped")
        return
    w(f"\ngene-held-out cross-validation ({len(genes)} folds)")
    w(f"  {'held-out gene':<28} {'n':>6} {'candidate':>10} {'entropy':>9} "
      f"{'partial':>9}")
    w("  " + "-" * 65)
    wins = 0
    for g in genes:
        held = [r for r in recs if r["gene"] == g]
        if len(held) < 20:
            continue
        a = np.array([r["assay"] for r in held])
        c = np.array([r["candidate"] for r in held])
        e = np.array([r["entropy"] for r in held])
        rc, re_, rp = spearman(c, a), spearman(e, a), partial_spearman(c, a, e)
        wins += abs(rc) > abs(re_)
        w(f"  {g[:28]:<28} {len(held):>6} {rc:>+10.3f} {re_:>+9.3f} {rp:>+9.3f}")
    w(f"\n  candidate outperformed entropy on {wins} of {len(genes)} held-out genes")
    w("  Folds are whole genes. Splitting variants at random would let the")
    w("  shared alignment and conservation profile leak across folds.")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--assays", required=True,
                    help="directory of assay CSVs, one per gene")
    ap.add_argument("--alignments", required=True,
                    help="directory of alignments, named <gene>.fa")
    ap.add_argument("--predictors", help="optional CSV of precomputed predictors")
    ap.add_argument("--out", default="benchmark_results")
    args = ap.parse_args()

    assay_files = sorted(glob.glob(os.path.join(args.assays, "*.csv")))
    if not assay_files:
        print(f"no CSVs found in {args.assays}", file=sys.stderr)
        sys.exit(2)

    all_recs = []
    for path in assay_files:
        gene = os.path.splitext(os.path.basename(path))[0]
        aln = os.path.join(args.alignments, f"{gene}.fa")
        if not os.path.exists(aln):
            print(f"  skipping {gene}: no alignment at {aln}")
            continue
        rows = load_assay(path)
        if not rows:
            print(f"  skipping {gene}: no parseable variants")
            continue
        msa = [s for _, s in read_fasta(aln)]
        recs = evaluate_gene(gene, rows, msa)
        print(f"  {gene}: {len(recs)} variants scored")
        all_recs.extend(recs)

    if not all_recs:
        print("nothing to evaluate", file=sys.stderr)
        sys.exit(1)

    with open(f"{args.out}.txt", "w", encoding="utf-8") as out:
        report_levels(all_recs, "ALL GENES POOLED", out)
        gene_held_out_cv(all_recs, out)
        if args.predictors:
            out.write("\nExternal predictor comparison requires REVEL, "
                      "AlphaMissense and ESM-1b to be run separately and "
                      "supplied via --predictors; merge on (gene, variant) and "
                      "report the same four levels.\n")

    import csv as _csv
    with open(f"{args.out}_variants.csv", "w", newline="", encoding="utf-8") as fh:
        wr = _csv.DictWriter(fh, fieldnames=list(all_recs[0].keys()))
        wr.writeheader()
        wr.writerows(all_recs)
    print(f"\nwrote {args.out}.txt and {args.out}_variants.csv")


if __name__ == "__main__":
    main()
